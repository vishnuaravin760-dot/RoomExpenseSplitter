package com.example.roomexpensesplitter

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.time.LocalDate
import java.util.Locale
import kotlin.math.abs

data class Member(val id: Int, val name: String)
data class Expense(
    val id: Long,
    val title: String,
    val amount: Double,
    val payerId: Int,
    val participants: Set<Int>,
    val month: String,
    val category: String
)

private val categories = listOf("Rent", "Gas / Water", "Lottery", "Mess", "Car", "Other")

class ExpenseStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("room_expenses", Context.MODE_PRIVATE)

    fun loadMembers(): List<Member> {
        val raw = prefs.getString("members", null) ?: return listOf(
            Member(1, "maneesh"), Member(2, "vishnu"), Member(3, "aneesh"),
            Member(4, "githin"), Member(5, "binish"), Member(6, "shahul"), Member(7, "anoop")
        )
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Member(o.getInt("id"), o.getString("name"))
        }
    }

    fun saveMembers(members: List<Member>) {
        val arr = JSONArray()
        members.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name)) }
        prefs.edit().putString("members", arr.toString()).apply()
    }

    fun loadExpenses(): List<Expense> {
        val raw = prefs.getString("expenses", "[]")!!
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val p = o.getJSONArray("participants")
            Expense(
                o.getLong("id"), o.optString("title", "Expense"), o.getDouble("amount"),
                o.getInt("payerId"), (0 until p.length()).map { p.getInt(it) }.toSet(),
                o.optString("month", LocalDate.now().toString().substring(0, 7)),
                o.optString("category", "Other")
            )
        }
    }

    fun isCarVisible(): Boolean = prefs.getBoolean("show_car_column", false)

    fun setCarVisible(visible: Boolean) {
        prefs.edit().putBoolean("show_car_column", visible).apply()
    }

    fun saveExpenses(expenses: List<Expense>) {
        val arr = JSONArray()
        expenses.forEach { e ->
            val p = JSONArray()
            e.participants.forEach { p.put(it) }
            arr.put(JSONObject()
                .put("id", e.id).put("title", e.title).put("amount", e.amount)
                .put("payerId", e.payerId).put("participants", p).put("month", e.month)
                .put("category", e.category))
        }
        prefs.edit().putString("expenses", arr.toString()).apply()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RoomExpenseApp(this) }
    }
}

private fun money(v: Double): String = NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply {
    maximumFractionDigits = 2
    minimumFractionDigits = 2
}.format(v)

private fun categoryNet(expenses: List<Expense>, memberId: Int, category: String): Double {
    var value = 0.0
    expenses.filter { it.category == category }.forEach { e ->
        if (e.category == "Mess") {
            // Mess: the entered total is split equally among selected people.
            if (e.participants.isNotEmpty() && memberId in e.participants) {
                value -= e.amount / e.participants.size.toDouble()
            }
            // The person who paid gets the full amount as credit.
            if (memberId == e.payerId) value += e.amount
        } else {
            // Rent, Gas / Water, Lottery and Other: the entered number
            // is the fixed amount for each member. No payer, no division.
            if (memberId in e.participants) value += e.amount
        }
    }
    return value
}

private fun totalNet(expenses: List<Expense>, memberId: Int): Double =
    categories.sumOf { categoryNet(expenses, memberId, it) }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoomExpenseApp(context: Context) {
    val store = remember { ExpenseStore(context) }
    var members by remember { mutableStateOf(store.loadMembers()) }
    var expenses by remember { mutableStateOf(store.loadExpenses()) }
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    val month = LocalDate.now().toString().substring(0, 7)
    val monthExpenses = expenses.filter { it.month == month }
    var showCar by remember { mutableStateOf(store.isCarVisible()) }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(title = {
                    Column {
                        Text("🏠 HOUSEHOLD EXPENSE TRACKER 💰", fontWeight = FontWeight.Bold)
                        Text("Room Expense Splitter", style = MaterialTheme.typography.labelSmall)
                    }
                })
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }) {
                    Icon(Icons.Default.Add, contentDescription = "Add expense")
                }
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(tab == 0, { tab = 0 }, icon = { Icon(Icons.Default.TableChart, null) }, label = { Text("Tracker") })
                    NavigationBarItem(tab == 1, { tab = 1 }, icon = { Icon(Icons.Default.ReceiptLong, null) }, label = { Text("Expenses") })
                    NavigationBarItem(tab == 2, { tab = 2 }, icon = { Icon(Icons.Default.People, null) }, label = { Text("People") })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> TrackerScreen(
                    Modifier.padding(padding), members, monthExpenses, showCar,
                    onToggleCar = {
                        showCar = !showCar
                        store.setCarVisible(showCar)
                    }
                )
                1 -> ExpensesScreen(Modifier.padding(padding), members, monthExpenses) { id ->
                    expenses = expenses.filterNot { it.id == id }
                    store.saveExpenses(expenses)
                }
                else -> PeopleScreen(Modifier.padding(padding), members) { updated ->
                    members = updated
                    store.saveMembers(updated)
                }
            }
        }

        if (showAdd) {
            AddExpenseDialog(
                members = members,
                onDismiss = { showAdd = false },
                onSave = { title, amount, payer, participants, category ->
                    val e = Expense(System.currentTimeMillis(), title, amount, payer, participants, month, category)
                    expenses = expenses + e
                    store.saveExpenses(expenses)
                    showAdd = false
                }
            )
        }
    }
}

@Composable
private fun TrackerScreen(
    modifier: Modifier,
    members: List<Member>,
    expenses: List<Expense>,
    showCar: Boolean,
    onToggleCar: () -> Unit
) {
    // Single-page tracker: no horizontal/vertical scrolling. Car stays available
    // but is hidden by default and can be toggled without leaving this screen.
    val nameWeight = 1.25f
    val cellWeight = 1f
    val visibleCategories = categories.filter { it != "Car" || showCar }

    Column(
        modifier = modifier.fillMaxSize().padding(horizontal = 3.dp, vertical = 2.dp),
        verticalArrangement = Arrangement.spacedBy(1.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "HOUSEHOLD EXPENSE TRACKER",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
                Text(
                    "Current month • ${expenses.size} expense(s)",
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 1
                )
            }
            TextButton(
                onClick = onToggleCar,
                contentPadding = PaddingValues(horizontal = 5.dp, vertical = 0.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Text(if (showCar) "Hide Car" else "Show Car", fontSize = 11.sp, maxLines = 1)
            }
        }

        Row(Modifier.fillMaxWidth()) {
            CompactHeaderCell("NAME", nameWeight, Color(0xFF123B70))
            visibleCategories.forEach { category ->
                CompactHeaderCell(
                    category.replace("Gas / Water", "GAS /\nWATER").uppercase(),
                    cellWeight,
                    Color(0xFF123B70)
                )
            }
            CompactHeaderCell("TOTAL", cellWeight, Color(0xFF0B7A3A))
        }

        members.forEach { member ->
            Row(Modifier.fillMaxWidth()) {
                CompactNameCell(member.name, nameWeight)
                visibleCategories.forEach { category ->
                    CompactValueCell(categoryNet(expenses, member.id, category), cellWeight)
                }
                CompactValueCell(
                    visibleCategories.sumOf { categoryNet(expenses, member.id, it) },
                    cellWeight,
                    total = true
                )
            }
        }

        Row(Modifier.fillMaxWidth()) {
            CompactHeaderCell("TOTAL", nameWeight, Color(0xFFDDEBD5), Color.Black)
            visibleCategories.forEach { category ->
                CompactValueCell(
                    members.sumOf { categoryNet(expenses, it.id, category) },
                    cellWeight,
                    total = true
                )
            }
            CompactValueCell(
                members.sumOf { member -> visibleCategories.sumOf { categoryNet(expenses, member.id, it) } },
                cellWeight,
                total = true
            )
        }

        Text(
            "Mess: equal split • Others: entered amount per person • no payer",
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1
        )
    }
}

@Composable
private fun CompactHeaderCell(
    text: String,
    weight: Float,
    background: Color,
    textColor: Color = Color.White
) {
    Box(
        Modifier.weight(weight).height(36.dp).background(background).padding(2.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = textColor,
            fontWeight = FontWeight.Bold,
            fontSize = 8.sp,
            lineHeight = 9.sp,
            textAlign = TextAlign.Center,
            maxLines = 2
        )
    }
}

@Composable
private fun CompactNameCell(name: String, weight: Float) {
    Box(
        Modifier.weight(weight).height(30.dp).background(Color(0xFFEAF2F8)).padding(horizontal = 3.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(name, fontWeight = FontWeight.SemiBold, fontSize = 9.sp, maxLines = 1)
    }
}

@Composable
private fun CompactValueCell(value: Double, weight: Float, total: Boolean = false) {
    val positive = value > 0.005
    val negative = value < -0.005
    val textColor = when {
        negative -> Color(0xFFB3261E)
        positive && total -> Color(0xFF087A38)
        else -> Color.DarkGray
    }
    Box(
        Modifier.weight(weight).height(30.dp).padding(1.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            money(value),
            color = textColor,
            fontWeight = if (total) FontWeight.Bold else FontWeight.Normal,
            fontSize = 8.sp,
            maxLines = 1
        )
    }
}

@Composable
private fun HeaderCell(text: String, width: androidx.compose.ui.unit.Dp, background: Color, textColor: Color = Color.White) {
    Box(Modifier.width(width).height(72.dp).background(background).padding(5.dp), contentAlignment = Alignment.Center) {
        Text(text, color = textColor, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun NameCell(name: String, width: androidx.compose.ui.unit.Dp) {
    Box(Modifier.width(width).height(54.dp).background(Color(0xFFEAF2F8)).padding(horizontal = 8.dp), contentAlignment = Alignment.CenterStart) {
        Text(name, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ValueCell(value: Double, width: androidx.compose.ui.unit.Dp, total: Boolean = false) {
    val positive = value > 0.005
    val negative = value < -0.005
    val textColor = when {
        negative -> Color(0xFFB3261E)
        positive && total -> Color(0xFF087A38)
        else -> Color.DarkGray
    }
    Box(Modifier.width(width).height(54.dp).padding(1.dp), contentAlignment = Alignment.Center) {
        Text(money(value), color = textColor, fontWeight = if (total) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun ExpensesScreen(modifier: Modifier, members: List<Member>, expenses: List<Expense>, onDelete: (Long) -> Unit) {
    val names = members.associateBy { it.id }
    LazyColumn(modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (expenses.isEmpty()) item { Text("No expenses this month. Tap + to add one.") }
        items(expenses) { e ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${e.category} • ${e.title}", fontWeight = FontWeight.Bold)
                        if (e.category == "Mess") {
                            Text("${money(e.amount)} • paid by ${names[e.payerId]?.name ?: "Unknown"}")
                        } else {
                            Text("${money(e.amount)} • fixed amount per person • no payer")
                        }
                        Text("Split: ${e.participants.joinToString { names[it]?.name ?: "?" }}")
                    }
                    IconButton(onClick = { onDelete(e.id) }) { Icon(Icons.Default.Delete, "Delete") }
                }
            }
        }
    }
}

@Composable
private fun PeopleScreen(modifier: Modifier, members: List<Member>, onSave: (List<Member>) -> Unit) {
    var names by remember(members) { mutableStateOf(members.associate { it.id to it.name }) }
    var nextId by remember(members) { mutableIntStateOf((members.maxOfOrNull { it.id } ?: 0) + 1) }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Room members", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(names.keys.toList()) { id ->
                OutlinedTextField(
                    value = names[id] ?: "",
                    onValueChange = { names = names.toMutableMap().apply { put(id, it) } },
                    label = { Text("Person $id") }, modifier = Modifier.fillMaxWidth()
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                names = names.toMutableMap().apply { put(nextId, "Person $nextId") }
                nextId++
            }) { Text("Add person") }
            Button(onClick = { onSave(names.map { Member(it.key, it.value.ifBlank { "Person ${it.key}" }) }) }) { Text("Save") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddExpenseDialog(
    members: List<Member>,
    onDismiss: () -> Unit,
    onSave: (String, Double, Int, Set<Int>, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var payer by remember { mutableIntStateOf(members.firstOrNull()?.id ?: 1) }
    var selected by remember { mutableStateOf(members.map { it.id }.toSet()) }
    var category by remember { mutableStateOf("Mess") }
    var categoryExpanded by remember { mutableStateOf(false) }
    var payerExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("➕ Add Expense") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ExposedDropdownMenuBox(categoryExpanded, { categoryExpanded = !categoryExpanded }) {
                    OutlinedTextField(category, {}, readOnly = true, label = { Text("Category") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(categoryExpanded, { categoryExpanded = false }) {
                        categories.forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { category = c; categoryExpanded = false }) }
                    }
                }
                OutlinedTextField(title, { title = it }, label = { Text("Description (optional)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    amountText, { amountText = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("Amount (₹)") }, modifier = Modifier.fillMaxWidth()
                )
                if (category == "Mess") {
                    ExposedDropdownMenuBox(payerExpanded, { payerExpanded = !payerExpanded }) {
                        OutlinedTextField(
                            value = members.firstOrNull { it.id == payer }?.name ?: "",
                            onValueChange = {}, readOnly = true, label = { Text("Paid by") },
                            modifier = Modifier.menuAnchor().fillMaxWidth()
                        )
                        ExposedDropdownMenu(payerExpanded, { payerExpanded = false }) {
                            members.forEach { m -> DropdownMenuItem(text = { Text(m.name) }, onClick = { payer = m.id; payerExpanded = false }) }
                        }
                    }
                    Text("Who shares this expense?", fontWeight = FontWeight.SemiBold)
                    members.forEach { m ->
                        Row(
                            Modifier.fillMaxWidth().toggleable(selected.contains(m.id)) { checked ->
                                selected = if (checked) selected + m.id else selected - m.id
                            }, verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(selected.contains(m.id), null)
                            Text(m.name)
                        }
                    }
                } else {
                    // Non-Mess categories use the entered number as a fixed amount per person.
                    // Everyone is included automatically and there is no "Paid by" field.
                    selected = members.map { it.id }.toSet()
                    Text("Fixed amount per person • no payer", fontWeight = FontWeight.SemiBold)
                }
                val amount = amountText.toDoubleOrNull()
                if (selected.isNotEmpty() && amount != null && amount > 0) {
                    Text(
                        if (category == "Mess") "Each share: ${money(amount / selected.size)}"
                        else "Fixed amount per person: ${money(amount)}",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        },
        confirmButton = {
            Button(
                enabled = amountText.toDoubleOrNull()?.let { it > 0 } == true && selected.isNotEmpty(),
                onClick = { onSave(title.ifBlank { category }, amountText.toDouble(), if (category == "Mess") payer else 0, selected, category) }
            ) { Text("Save Expense") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
