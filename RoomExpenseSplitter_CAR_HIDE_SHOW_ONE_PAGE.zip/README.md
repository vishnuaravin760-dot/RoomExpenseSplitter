# Room Expense Splitter

Expense rules:
- **Mess:** enter the total, choose the person who paid, select the people sharing it. The Mess total is divided equally among selected people.
- **Rent:** enter the fixed amount per person. No Paid by field and no multiplication/division.
- **Gas / Water:** enter the fixed amount per person. No Paid by field and no multiplication/division.
- **Lottery:** enter the fixed amount per person. No Paid by field and no multiplication/division.
- **Car / Other:** enter the fixed amount per person. No Paid by field and no multiplication/division.

Money values are displayed with 2 decimal places.


Car is still available as an expense category. Its tracker column is hidden by default and can be shown with the Show Car button when needed.
