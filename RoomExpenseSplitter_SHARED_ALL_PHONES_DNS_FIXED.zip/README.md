# RoomExpenseSplitter — Shared All Phones

This build uses Firebase Realtime Database REST directly. It does NOT call
identitytoolkit.googleapis.com, so a DNS failure for Firebase Authentication
cannot block the Add Expense screen.

All phones using this same Firebase project and database path share the same
members and expenses.

## Required Firebase Realtime Database rules

Because this build does not use Firebase Authentication, set the rules to:

{
  "rules": {
    ".read": true,
    ".write": true
  }
}

WARNING: public read/write is appropriate only for a private test/household
project. For a production deployment, switch back to authenticated rules.
