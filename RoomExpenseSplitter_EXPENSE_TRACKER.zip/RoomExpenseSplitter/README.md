# Room Expense Splitter

Android app MVP for a shared room with up to any number of people.

## Main feature
For every expense you choose:
- who paid
- exactly which people participated
- equal split among only those selected

Example: 7 people live in the room. Electricity = 7 people, dinner = 4 people, taxi = 2 people. The app calculates each person's monthly balance.

## Run
Open this folder in Android Studio (Ladybug or newer), let Gradle sync, then Run on an Android phone/emulator.

The app stores members and expenses locally using SharedPreferences. No internet/backend is required for this MVP.

## Possible next upgrades
- custom unequal shares
- recurring rent/internet/electricity
- monthly history
- settlement suggestions ("A pays B CHF 18")
- export to PDF/Excel
- multi-currency
- login + cloud sync
- Malayalam UI
