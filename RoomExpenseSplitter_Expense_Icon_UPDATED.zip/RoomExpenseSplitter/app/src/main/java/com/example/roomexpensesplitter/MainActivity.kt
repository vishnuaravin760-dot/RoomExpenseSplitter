package com.example.roomexpensesplitter

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.time.LocalDate
import java.util.Locale
import kotlin.math.abs

val EXPENSE_CATEGORIES = listOf("Rent", "Gas / Water", "Lottery", "Car", "Mess", "Other")

data class Member(val id: Int, val name: String)
data class Expense(
    val id: Long,
    val title: String,
    val amount: Double,
    val payerId: Int,
    val participants: Set<Int>,
    val month: String,
    val category: String = "Other"
)

class ExpenseStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("room_expenses", Context.MODE_PRIVATE)

    fun loadMembers(): List<Member> {
        val raw = prefs.getString("members", null)
            ?: return (1..7).map { Member(it, "Person $it") }
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Member(o.getInt("id"), o.getString("name"))
        }
    }

    fun saveMembers(members: List<Member>) {
        val arr = JSONArray()
        members.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name)) }
        prefs.edit().putString("members", arr.toString()).apply()
    }

    fun loadExpenses(): List<Expense> {
        val raw = prefs.getString("expenses", "[]")!!
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val p = o.getJSONArray("participants")
            Expense(
                o.getLong("id"),
                o.getString("title"),
                o.getDouble("amount"),
                o.getInt("payerId"),
                (0 until p.length()).map { p.getInt(it) }.toSet(),
                o.getString("month"),
                o.optString("category", "Other")
            )
        }
    }

    fun saveExpenses(expenses: List<Expense>) {
        val arr = JSONArray()
        expenses.forEach { e ->
            val p = JSONArray()
            e.participants.forEach { p.put(it) }
            arr.put(
                JSONObject()
                    .put("id", e.id)
                    .put("title", e.title)
                    .put("amount", e.amount)
                    .put("payerId", e.payerId)
                    .put("participants", p)
                    .put("month", e.month)
                    .put("category", e.category)
            )
        }
        prefs.edit().putString("expenses", arr.toString()).apply()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RoomExpenseApp(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoomExpenseApp(context: Context) {
    val store = remember { ExpenseStore(context) }
    var members by remember { mutableStateOf(store.loadMembers()) }
    var expenses by remember { mutableStateOf(store.loadExpenses()) }
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }

    val month = LocalDate.now().toString().substring(0, 7)
    val monthExpenses = expenses.filter { it.month == month }
    val balances = calculateBalances(members, monthExpenses)

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Room Expense Splitter") }) },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }) {
                    Icon(Icons.Default.Add, contentDescription = "Add expense")
                }
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = tab == 0, onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.Home, null) }, label = { Text("Summary") }
                    )
                    NavigationBarItem(
                        selected = tab == 1, onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.ReceiptLong, null) }, label = { Text("Expenses") }
                    )
                    NavigationBarItem(
                        selected = tab == 2, onClick = { tab = 2 },
                        icon = { Icon(Icons.Default.People, null) }, label = { Text("People") }
                    )
                }
            }
        ) { padding ->
            when (tab) {
                0 -> SummaryScreen(
                    modifier = Modifier.padding(padding),
                    members = members,
                    balances = balances,
                    expenses = monthExpenses
                )
                1 -> ExpensesScreen(
                    modifier = Modifier.padding(padding),
                    members = members,
                    expenses = monthExpenses
                ) { id ->
                    expenses = expenses.filterNot { it.id == id }
                    store.saveExpenses(expenses)
                }
                2 -> PeopleScreen(
                    modifier = Modifier.padding(padding),
                    members = members
                ) { updated ->
                    members = updated
                    store.saveMembers(updated)
                }
            }
        }

        if (showAdd) {
            AddExpenseDialog(
                members = members,
                onDismiss = { showAdd = false },
                onSave = { title, amount, payer, participants, category ->
                    val e = Expense(
                        System.currentTimeMillis(),
                        title,
                        amount,
                        payer,
                        participants,
                        month,
                        category
                    )
                    expenses = expenses + e
                    store.saveExpenses(expenses)
                    showAdd = false
                }
            )
        }
    }
}

fun calculateBalances(members: List<Member>, expenses: List<Expense>): Map<Int, Double> {
    val b = members.associate { it.id to 0.0 }.toMutableMap()
    expenses.forEach { e ->
        if (e.participants.isNotEmpty()) {
            val share = e.amount / e.participants.size
            e.participants.forEach { id -> b[id] = (b[id] ?: 0.0) - share }
            b[e.payerId] = (b[e.payerId] ?: 0.0) + e.amount
        }
    }
    return b
}

fun money(v: Double): String =
    NumberFormat.getCurrencyInstance(Locale.getDefault()).format(v)

@Composable
fun SummaryScreen(
    modifier: Modifier,
    members: List<Member>,
    balances: Map<Int, Double>,
    expenses: List<Expense>
) {
    val horizontal = rememberScrollState()
    val categoryTotals = EXPENSE_CATEGORIES.associateWith { category ->
        expenses.filter { it.category == category }.sumOf { it.amount }
    }

    LazyColumn(
        modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("This month", style = MaterialTheme.typography.headlineSmall)
            Text("Total expenses: ${money(expenses.sumOf { it.amount })}")
        }

        item {
            Text("Expense tracker", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(6.dp))
            Text("Each cell shows this person's share of that category.")
        }

        item {
            Card(Modifier.fillMaxWidth()) {
                Row(
                    Modifier
                        .horizontalScroll(horizontal)
                        .padding(8.dp)
                ) {
                    TrackerCell("NAME", true)
                    EXPENSE_CATEGORIES.forEach { TrackerCell(it, true) }
                    TrackerCell("TOTAL", true)
                }
            }
        }

        items(members) { member ->
            val rowTotal = expenses
                .filter { it.participants.contains(member.id) }
                .sumOf { it.amount / it.participants.size }
            Card(Modifier.fillMaxWidth()) {
                Row(
                    Modifier
                        .horizontalScroll(horizontal)
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TrackerCell(member.name)
                    EXPENSE_CATEGORIES.forEach { category ->
                        val value = expenses
                            .filter {
                                it.category == category &&
                                    it.participants.contains(member.id)
                            }
                            .sumOf { it.amount / it.participants.size }
                        TrackerCell(money(value))
                    }
                    TrackerCell(money(rowTotal))
                }
            }
        }

        item {
            Text("Category totals", style = MaterialTheme.typography.titleLarge)
        }
        items(EXPENSE_CATEGORIES.filter { (categoryTotals[it] ?: 0.0) > 0.0 }) { category ->
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(category)
                Text(money(categoryTotals[category] ?: 0.0))
            }
        }

        item { HorizontalDivider() }
        item { Text("Balances", style = MaterialTheme.typography.titleLarge) }

        items(members) { m ->
            val v = balances[m.id] ?: 0.0
            Card(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(m.name)
                    Text(
                        when {
                            v > 0.005 -> "Gets ${money(v)}"
                            v < -0.005 -> "Pays ${money(abs(v))}"
                            else -> "Settled"
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun TrackerCell(text: String, header: Boolean = false) {
    Box(
        Modifier.width(if (header) 92.dp else 100.dp).padding(horizontal = 4.dp, vertical = 8.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(
            text,
            style = if (header) MaterialTheme.typography.labelMedium
            else MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
fun ExpensesScreen(
    modifier: Modifier,
    members: List<Member>,
    expenses: List<Expense>,
    onDelete: (Long) -> Unit
) {
    val names = members.associateBy { it.id }
    LazyColumn(
        modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (expenses.isEmpty()) {
            item { Text("No expenses this month. Tap + to add one.") }
        }
        items(expenses) { e ->
            Card(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(e.title, style = MaterialTheme.typography.titleMedium)
                        Text("${money(e.amount)} • ${e.category}")
                        Text("Paid by ${names[e.payerId]?.name ?: "Unknown"}")
                        Text(
                            "Split between ${e.participants.size}: " +
                                e.participants.joinToString { names[it]?.name ?: "?" }
                        )
                    }
                    IconButton(onClick = { onDelete(e.id) }) {
                        Icon(Icons.Default.Delete, "Delete")
                    }
                }
            }
        }
    }
}

@Composable
fun PeopleScreen(
    modifier: Modifier,
    members: List<Member>,
    onSave: (List<Member>) -> Unit
) {
    var names by remember(members) {
        mutableStateOf(members.associate { it.id to it.name })
    }
    var nextId by remember(members) {
        mutableIntStateOf((members.maxOfOrNull { it.id } ?: 0) + 1)
    }

    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Room members", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        LazyColumn(
            Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(names.keys.toList()) { id ->
                OutlinedTextField(
                    value = names[id] ?: "",
                    onValueChange = {
                        names = names.toMutableMap().apply { put(id, it) }
                    },
                    label = { Text("Person $id") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                names = names.toMutableMap().apply { put(nextId, "Person $nextId") }
                nextId++
            }) { Text("Add person") }
            Button(onClick = {
                onSave(
                    names.map {
                        Member(it.key, it.value.ifBlank { "Person ${it.key}" })
                    }
                )
            }) { Text("Save") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddExpenseDialog(
    members: List<Member>,
    onDismiss: () -> Unit,
    onSave: (String, Double, Int, Set<Int>, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var payer by remember { mutableIntStateOf(members.firstOrNull()?.id ?: 1) }
    var selected by remember { mutableStateOf(members.map { it.id }.toSet()) }
    var payerExpanded by remember { mutableStateOf(false) }
    var category by remember { mutableStateOf("Other") }
    var categoryExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add expense") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Expense name") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        amountText = it.filter { c -> c.isDigit() || c == '.' }
                    },
                    label = { Text("Amount") },
                    modifier = Modifier.fillMaxWidth()
                )

                ExposedDropdownMenuBox(
                    expanded = categoryExpanded,
                    onExpandedChange = { categoryExpanded = !categoryExpanded }
                ) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Category") },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = categoryExpanded,
                        onDismissRequest = { categoryExpanded = false }
                    ) {
                        EXPENSE_CATEGORIES.forEach { item ->
                            DropdownMenuItem(
                                text = { Text(item) },
                                onClick = {
                                    category = item
                                    categoryExpanded = false
                                }
                            )
                        }
                    }
                }

                ExposedDropdownMenuBox(
                    expanded = payerExpanded,
                    onExpandedChange = { payerExpanded = !payerExpanded }
                ) {
                    OutlinedTextField(
                        value = members.firstOrNull { it.id == payer }?.name ?: "",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Paid by") },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = payerExpanded,
                        onDismissRequest = { payerExpanded = false }
                    ) {
                        members.forEach { m ->
                            DropdownMenuItem(
                                text = { Text(m.name) },
                                onClick = {
                                    payer = m.id
                                    payerExpanded = false
                                }
                            )
                        }
                    }
                }

                Text("Who should share this expense?")
                members.forEach { m ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .toggleable(
                                value = selected.contains(m.id),
                                onValueChange = {
                                    selected = if (it) selected + m.id else selected - m.id
                                }
                            ),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(selected.contains(m.id), null)
                        Text(m.name)
                    }
                }

                if (selected.isNotEmpty() && amountText.toDoubleOrNull() != null) {
                    Text(
                        "Each pays: ${
                            money(amountText.toDouble() / selected.size)
                        }"
                    )
                }
            }
        },
        confirmButton = {
            Button(
                enabled = title.isNotBlank() &&
                    amountText.toDoubleOrNull() != null &&
                    amountText.toDouble() > 0 &&
                    selected.isNotEmpty(),
                onClick = {
                    onSave(
                        title,
                        amountText.toDouble(),
                        payer,
                        selected,
                        category
                    )
                }
            ) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
