package com.example.roomexpensesplitter

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.time.LocalDate
import java.util.Locale

data class Member(val id: Int = 0, val name: String = "")
data class Expense(
    val id: Long = 0L,
    val title: String = "Expense",
    val amount: Double = 0.0,
    val payerId: Int = 0,
    val participants: Set<Int> = emptySet(),
    val month: String = "",
    val category: String = "Other"
)

private val categories = listOf("Rent", "Gas / Water", "Lottery", "Mess", "Car", "Other")
private val defaultMembers = listOf(
    Member(1, "maneesh"), Member(2, "vishnu"), Member(3, "aneesh"),
    Member(4, "githin"), Member(5, "binish"), Member(6, "shahul"), Member(7, "anoop")
)

/**
 * Shared cloud store. Every installed copy of the app reads/writes the same
 * household/default path, so an expense added on one phone appears on all
 * other phones in real time.
 */
class FirebaseExpenseStore(private val context: Context) {
    // REST mode: no Firebase Android SDK is loaded at startup. Anonymous
    // authentication is done through the Identity Toolkit REST endpoint and
    // Realtime Database is accessed over HTTPS. This avoids FirebaseInitProvider
    // crashes while keeping the same shared Firebase database.
    private val apiKey = "AIzaSyAL2eM_fmfYqRv3K1tMTaz9oYFnwfJWErQ"
    private val databaseUrl = "https://roomexpensesplitter-47254-default-rtdb.firebaseio.com"
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private var idToken: String? = null
    private var running = false
    private var onDataCallback: ((List<Member>, List<Expense>) -> Unit)? = null
    private var onReadyCallback: (() -> Unit)? = null
    private var onErrorCallback: ((String) -> Unit)? = null
    private val pendingExpenses = java.util.Collections.synchronizedList(mutableListOf<Expense>())
    private val pendingDeletes = java.util.Collections.synchronizedList(mutableListOf<Long>())

    fun start(
        onData: (List<Member>, List<Expense>) -> Unit,
        onReady: () -> Unit,
        onError: (String) -> Unit
    ) {
        if (running) return
        running = true
        onDataCallback = onData
        onReadyCallback = onReady
        onErrorCallback = onError
        Thread { authenticateAndPoll() }.start()
    }

    private fun authenticateAndPoll() {
        try {
            val existing = idToken
            if (existing == null) idToken = anonymousSignIn()
            if (idToken.isNullOrBlank()) throw IllegalStateException("Anonymous sign-in failed")
            flushPendingWrites()
            handler.post { onReadyCallback?.invoke() }
            pollLoop()
        } catch (t: Throwable) {
            handler.post { onErrorCallback?.invoke(t.message ?: t.javaClass.simpleName) }
            running = false
        }
    }

    private fun flushPendingWrites() {
        val token = idToken ?: return
        val expensesToSave = synchronized(pendingExpenses) {
            val copy = pendingExpenses.toList()
            pendingExpenses.clear()
            copy
        }
        expensesToSave.forEach { e ->
            try {
                val participants = org.json.JSONObject().apply {
                    e.participants.forEach { put(it.toString(), true) }
                }
                val data = org.json.JSONObject().apply {
                    put("id", e.id)
                    put("title", e.title)
                    put("amount", e.amount)
                    put("payerId", e.payerId)
                    put("participants", participants)
                    put("month", e.month)
                    put("category", e.category)
                }
                httpPut("$databaseUrl/household/default/expenses/${e.id}.json?auth=$token", data.toString())
            } catch (t: Throwable) {
                pendingExpenses.add(e)
            }
        }
        val deletesToApply = synchronized(pendingDeletes) {
            val copy = pendingDeletes.toList()
            pendingDeletes.clear()
            copy
        }
        deletesToApply.forEach { id ->
            try { httpDelete("$databaseUrl/household/default/expenses/$id.json?auth=$token") }
            catch (_: Throwable) { pendingDeletes.add(id) }
        }
    }

    private fun pollLoop() {
        while (running) {
            try {
                val token = idToken ?: throw IllegalStateException("No Firebase token")
                val json = httpGet("$databaseUrl/household/default.json?auth=$token")
                val (members, expenses) = parseRoot(json)
                handler.post { onDataCallback?.invoke(members, expenses) }
            } catch (t: Throwable) {
                handler.post { onErrorCallback?.invoke(t.message ?: "Database sync failed") }
                // Retry after a short delay; keep the UI alive even if the network is down.
            }
            try { Thread.sleep(2500) } catch (_: InterruptedException) { break }
        }
    }

    private fun anonymousSignIn(): String {
        val url = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$apiKey"
        val body = "{\"returnSecureToken\":true}"
        val json = httpPost(url, body)
        return org.json.JSONObject(json).getString("idToken")
    }

    private fun httpGet(url: String): String {
        val conn = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10000
            readTimeout = 10000
        }
        return readResponse(conn)
    }

    private fun httpPost(url: String, body: String): String {
        val conn = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 10000
            readTimeout = 10000
            setRequestProperty("Content-Type", "application/json")
        }
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        return readResponse(conn)
    }

    private fun httpPut(url: String, body: String) {
        val conn = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
            requestMethod = "PUT"
            doOutput = true
            connectTimeout = 10000
            readTimeout = 10000
            setRequestProperty("Content-Type", "application/json")
        }
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        readResponse(conn)
    }

    private fun httpDelete(url: String) {
        val conn = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
            requestMethod = "DELETE"
            connectTimeout = 10000
            readTimeout = 10000
        }
        readResponse(conn)
    }

    private fun readResponse(conn: java.net.HttpURLConnection): String {
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        conn.disconnect()
        if (code !in 200..299) throw IllegalStateException("Firebase HTTP $code: $text")
        return text
    }

    private fun parseRoot(json: String): Pair<List<Member>, List<Expense>> {
        if (json == "null" || json.isBlank()) return defaultMembers to emptyList()
        val root = org.json.JSONObject(json)
        val members = mutableListOf<Member>()
        root.optJSONObject("members")?.let { obj ->
            obj.keys().forEach { key ->
                val item = obj.optJSONObject(key)
                if (item != null) {
                    val id = item.optInt("id", key.toIntOrNull() ?: 0)
                    val name = item.optString("name", "")
                    if (id != 0 && name.isNotBlank()) members += Member(id, name)
                }
            }
        }
        val finalMembers = members.sortedBy { it.id }.ifEmpty { defaultMembers }
        val expenses = mutableListOf<Expense>()
        root.optJSONObject("expenses")?.let { obj ->
            obj.keys().forEach { key ->
                val item = obj.optJSONObject(key) ?: return@forEach
                val id = item.optLong("id", key.toLongOrNull() ?: 0L)
                if (id == 0L) return@forEach
                val participants = mutableSetOf<Int>()
                item.optJSONObject("participants")?.let { po ->
                    po.keys().forEach { pk ->
                        val v = po.opt(pk)
                        val pid = when (v) {
                            is Number -> v.toInt()
                            else -> pk.toIntOrNull()
                        }
                        if (pid != null) participants += pid
                    }
                }
                val amount = item.optDouble("amount", 0.0)
                val month = item.optString("month", LocalDate.now().toString().substring(0, 7))
                expenses += Expense(
                    id = id,
                    title = item.optString("title", "Expense"),
                    amount = amount,
                    payerId = item.optInt("payerId", 0),
                    participants = participants,
                    month = month,
                    category = item.optString("category", "Other")
                )
            }
        }
        return finalMembers to expenses.sortedBy { it.id }
    }

    fun saveExpense(e: Expense) {
        Thread {
            try {
                if (idToken == null) {
                    pendingExpenses.add(e)
                    return@Thread
                }
                val token = idToken ?: return@Thread
                val participants = org.json.JSONObject().apply {
                    e.participants.forEach { put(it.toString(), true) }
                }
                val data = org.json.JSONObject().apply {
                    put("id", e.id)
                    put("title", e.title)
                    put("amount", e.amount)
                    put("payerId", e.payerId)
                    put("participants", participants)
                    put("month", e.month)
                    put("category", e.category)
                }
                httpPut("$databaseUrl/household/default/expenses/${e.id}.json?auth=$token", data.toString())
            } catch (t: Throwable) {
                pendingExpenses.add(e)
                handler.post { onErrorCallback?.invoke(t.message ?: "Could not save expense; it will retry automatically") }
            }
        }.start()
    }

    fun deleteExpense(id: Long) {
        Thread {
            try {
                val token = idToken
                if (token == null) {
                    pendingDeletes.add(id)
                    return@Thread
                }
                httpDelete("$databaseUrl/household/default/expenses/$id.json?auth=$token")
            } catch (t: Throwable) {
                pendingDeletes.add(id)
                handler.post { onErrorCallback?.invoke(t.message ?: "Could not delete expense; it will retry automatically") }
            }
        }.start()
    }

    fun saveMembers(members: List<Member>) {
        Thread {
            try {
                val token = idToken ?: return@Thread
                val data = org.json.JSONObject().apply {
                    members.forEach { m ->
                        put(m.id.toString(), org.json.JSONObject().apply {
                            put("id", m.id)
                            put("name", m.name)
                        })
                    }
                }
                httpPut("$databaseUrl/household/default/members.json?auth=$token", data.toString())
            } catch (t: Throwable) {
                handler.post { onErrorCallback?.invoke(t.message ?: "Could not save members") }
            }
        }.start()
    }

    fun stop() {
        running = false
        onDataCallback = null
        onReadyCallback = null
        onErrorCallback = null
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RoomExpenseApp(this) }
    }
}

private fun money(v: Double): String = NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply {
    maximumFractionDigits = 2
    minimumFractionDigits = 2
}.format(v)

private fun categoryNet(
    expenses: List<Expense>,
    memberId: Int,
    category: String,
    allMemberIds: Set<Int> = emptySet()
): Double {
    var value = 0.0
    expenses.filter { it.category == category }.forEach { e ->
        if (e.category == "Mess") {
            // Equal split. For old records with no participant list, use all
            // current members so the bill does not appear as a single-person charge.
            val participantIds = if (e.participants.isNotEmpty()) e.participants else allMemberIds
            if (participantIds.isNotEmpty() && memberId in participantIds) {
                value += e.amount / participantIds.size.toDouble()
            }
            // Payer paid the full bill, so credit that payment back.
            if (memberId == e.payerId) value -= e.amount
        } else {
            if (memberId in e.participants) value += e.amount
        }
    }
    return value
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoomExpenseApp(context: Context) {
    var store by remember { mutableStateOf<FirebaseExpenseStore?>(null) }
    var members by remember { mutableStateOf(defaultMembers) }
    var expenses by remember { mutableStateOf(emptyList<Expense>()) }
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var firebaseReady by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf<String?>(null) }
    val month = LocalDate.now().toString().substring(0, 7)
    val monthExpenses = expenses.filter { it.month == month }
    var showCar by remember { mutableStateOf(false) }
    val prefs = remember { context.getSharedPreferences("room_expenses", Context.MODE_PRIVATE) }

    DisposableEffect(Unit) {
        showCar = prefs.getBoolean("show_car_column", false)
        onDispose { store?.stop() }
    }

    // Shared sync: every phone connects to the same Firebase project and the
    // same household/default path. Sync starts automatically so all phones
    // converge on the same members and expenses. Local writes are queued until
    // authentication is ready, so tapping + immediately never loses an expense.
    fun startSync() {
        if (firebaseReady) return
        errorText = null
        if (store == null) store = FirebaseExpenseStore(context.applicationContext)
        store?.start(
            onData = { cloudMembers, cloudExpenses ->
                members = cloudMembers
                expenses = cloudExpenses
            },
            onReady = { firebaseReady = true },
            onError = { errorText = it }
        )
    }

    LaunchedEffect(Unit) { startSync() }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("🏠 HOUSEHOLD EXPENSE TRACKER 💰", fontWeight = FontWeight.Bold)
                            Text(
                                if (firebaseReady) "Shared / Live Sync ON" else "Local mode — sync not started",
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    },
                    actions = {
                        TextButton(onClick = { startSync() }) {
                            Text(if (firebaseReady) "SYNC ON" else "SYNC…")
                        }
                    }
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }) { Text("+") }
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.TableChart, contentDescription = "Tracker") }, label = { Text("Tracker") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.ReceiptLong, contentDescription = "Expenses") }, label = { Text("Expenses") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.People, contentDescription = "People") }, label = { Text("People") })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> TrackerScreen(
                    Modifier.padding(padding), members, monthExpenses, showCar,
                    onToggleCar = {
                        showCar = !showCar
                        prefs.edit().putBoolean("show_car_column", showCar).apply()
                    }
                )
                1 -> ExpensesScreen(Modifier.padding(padding), members, monthExpenses) { id ->
                    expenses = expenses.filterNot { it.id == id }
                    store?.deleteExpense(id)
                }
                else -> PeopleScreen(Modifier.padding(padding), members) { updated ->
                    store?.saveMembers(updated)
                }
            }
        }

        if (showAdd) {
            AddExpenseDialog(
                members = members,
                onDismiss = { showAdd = false },
                onSave = { title, amount, payer, participants, category ->
                    val finalParticipants = if (category == "Mess" && participants.isEmpty()) {
                        members.map { it.id }.toSet()
                    } else {
                        participants
                    }
                    val e = Expense(System.currentTimeMillis(), title, amount, payer, finalParticipants, month, category)
                    // Show immediately and always send it to the shared cloud store.
                    // If authentication is still starting, the store queues the write.
                    expenses = (expenses + e).distinctBy { it.id }.sortedBy { it.id }
                    if (store == null) startSync()
                    store?.saveExpense(e)
                    showAdd = false
                }
            )
        }

        errorText?.let { message ->
            AlertDialog(
                onDismissRequest = { errorText = null },
                title = { Text("Firebase connection") },
                text = { Text(message) },
                confirmButton = { TextButton(onClick = { errorText = null }) { Text("OK") } }
            )
        }
    }
}

@Composable
private fun TrackerScreen(
    modifier: Modifier,
    members: List<Member>,
    expenses: List<Expense>,
    showCar: Boolean,
    onToggleCar: () -> Unit
) {
    val visibleCategories = categories.filter { it != "Car" || showCar }
    val nameWeight = 1.45f
    val cellWeight = 1f
    val totalWeight = nameWeight + (visibleCategories.size + 1) * cellWeight

    BoxWithConstraints(modifier.fillMaxSize()) {
        val nameWidth = maxWidth * (nameWeight / totalWeight)
        val cellWidth = maxWidth * (cellWeight / totalWeight)
        Column(Modifier.fillMaxSize().padding(horizontal = 2.dp, vertical = 1.dp)) {
            Row(Modifier.fillMaxWidth().height(34.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("HOUSEHOLD EXPENSE TRACKER", fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
                    Text("${expenses.size} expense(s) • current month", fontSize = 8.sp, maxLines = 1)
                }
                TextButton(onClick = onToggleCar, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp), modifier = Modifier.height(28.dp)) {
                    Text(if (showCar) "Hide Car" else "Car: Hidden", fontSize = 9.sp, maxLines = 1)
                }
            }
            Row(Modifier.fillMaxWidth().height(30.dp)) {
                CompactHeaderCell("NAME", nameWidth, Color(0xFF123B70))
                for (category in visibleCategories) {
                    CompactHeaderCell(category.replace("Gas / Water", "GAS /\nWATER").uppercase(), cellWidth, Color(0xFF123B70))
                }
                CompactHeaderCell("TOTAL", cellWidth, Color(0xFF0B7A3A))
            }
            for (member in members) {
                Row(Modifier.fillMaxWidth().height(26.dp)) {
                    CompactNameCell(member.name, nameWidth)
                    for (category in visibleCategories) {
                        CompactValueCell(categoryNet(expenses, member.id, category, members.map { it.id }.toSet()), cellWidth)
                    }
                    CompactValueCell(visibleCategories.sumOf { categoryNet(expenses, member.id, it, members.map { it.id }.toSet()) }, cellWidth, total = true)
                }
            }
            Row(Modifier.fillMaxWidth().height(26.dp)) {
                CompactHeaderCell("TOTAL", nameWidth, Color(0xFFDDEBD5), Color.Black)
                for (category in visibleCategories) {
                    CompactValueCell(members.sumOf { categoryNet(expenses, it.id, category, members.map { it.id }.toSet()) }, cellWidth, total = true)
                }
                CompactValueCell(members.sumOf { member -> visibleCategories.sumOf { categoryNet(expenses, member.id, it, members.map { it.id }.toSet()) } }, cellWidth, total = true)
            }
            Text("Mess: equal split • whoever pays the mess bill gets that payment deducted from their total • Rent/Water/Gas/Lottery: fixed amount per person", fontSize = 8.sp, maxLines = 1, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

@Composable
private fun CompactHeaderCell(text: String, width: androidx.compose.ui.unit.Dp, background: Color, textColor: Color = Color.White) {
    Box(Modifier.width(width).height(30.dp).background(background).padding(1.dp), contentAlignment = Alignment.Center) {
        Text(text, color = textColor, fontWeight = FontWeight.Bold, fontSize = 8.sp, lineHeight = 9.sp, textAlign = TextAlign.Center, maxLines = 2)
    }
}

@Composable
private fun CompactNameCell(name: String, width: androidx.compose.ui.unit.Dp) {
    Box(Modifier.width(width).height(26.dp).background(Color(0xFFEAF2F8)).padding(horizontal = 2.dp), contentAlignment = Alignment.CenterStart) {
        Text(name, fontWeight = FontWeight.SemiBold, fontSize = 8.sp, maxLines = 1)
    }
}

@Composable
private fun CompactValueCell(value: Double, width: androidx.compose.ui.unit.Dp, total: Boolean = false) {
    val positive = value > 0.005
    val negative = value < -0.005
    val textColor = when {
        negative -> Color(0xFFB3261E)
        positive && total -> Color(0xFF087A38)
        else -> Color.DarkGray
    }
    Box(Modifier.width(width).height(26.dp).padding(1.dp), contentAlignment = Alignment.Center) {
        Text(money(value), color = textColor, fontWeight = if (total) FontWeight.Bold else FontWeight.Normal, fontSize = 7.sp, maxLines = 1)
    }
}

@Composable
private fun ExpensesScreen(modifier: Modifier, members: List<Member>, expenses: List<Expense>, onDelete: (Long) -> Unit) {
    val names = members.associateBy { it.id }
    LazyColumn(modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (expenses.isEmpty()) item { Text("No expenses this month. Tap + to add one.") }
        items(expenses) { e ->
            Card(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("${e.category} • ${e.title}", fontWeight = FontWeight.Bold)
                        if (e.category == "Mess") {
                            Text("${money(e.amount)} • paid by ${names[e.payerId]?.name ?: "Unknown"}")
                            val participantIds = if (e.participants.isNotEmpty()) e.participants else members.map { it.id }.toSet()
                            val share = if (participantIds.isNotEmpty()) e.amount / participantIds.size else 0.0
                            Text("Split: " + participantIds.joinToString { id ->
                                "${names[id]?.name ?: "?"} ${money(share)}"
                            })
                        } else {
                            Text("${money(e.amount)} • fixed amount per person • no payer")
                            Text("Split: " + e.participants.joinToString { names[it]?.name ?: "?" })
                        }
                    }
                    TextButton(onClick = { onDelete(e.id) }) { Text("Delete") }
                }
            }
        }
    }
}

@Composable
private fun PeopleScreen(modifier: Modifier, members: List<Member>, onSave: (List<Member>) -> Unit) {
    var names by remember(members) { mutableStateOf(members.associate { it.id to it.name }) }
    var nextId by remember(members) { mutableIntStateOf((members.maxOfOrNull { it.id } ?: 0) + 1) }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Room members", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(names.keys.toList()) { id ->
                OutlinedTextField(value = names[id] ?: "", onValueChange = { names = names.toMutableMap().apply { put(id, it) } }, label = { Text("Person $id") }, modifier = Modifier.fillMaxWidth())
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { names = names.toMutableMap().apply { put(nextId, "Person $nextId") }; nextId++ }) { Text("Add person") }
            Button(onClick = { onSave(names.map { Member(it.key, it.value.ifBlank { "Person ${it.key}" }) }) }) { Text("Save") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddExpenseDialog(members: List<Member>, onDismiss: () -> Unit, onSave: (String, Double, Int, Set<Int>, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var payer by remember { mutableIntStateOf(members.firstOrNull()?.id ?: 1) }
    var selected by remember(members) { mutableStateOf(members.map { it.id }.toSet()) }
    var category by remember { mutableStateOf("Mess") }
    var categoryExpanded by remember { mutableStateOf(false) }
    var payerExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(category, members) {
        if (category != "Mess") selected = members.map { it.id }.toSet()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("➕ Add Expense") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ExposedDropdownMenuBox(expanded = categoryExpanded, onExpandedChange = { categoryExpanded = !categoryExpanded }) {
                    OutlinedTextField(value = category, onValueChange = {}, readOnly = true, label = { Text("Category") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = categoryExpanded, onDismissRequest = { categoryExpanded = false }) {
                        for (c in categories) {
                            DropdownMenuItem(text = { Text(c) }, onClick = { category = c; categoryExpanded = false })
                        }
                    }
                }
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Description (optional)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = amountText, onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Amount (₹)") }, modifier = Modifier.fillMaxWidth())
                if (category == "Mess") {
                    ExposedDropdownMenuBox(expanded = payerExpanded, onExpandedChange = { payerExpanded = !payerExpanded }) {
                        OutlinedTextField(value = members.firstOrNull { it.id == payer }?.name ?: "", onValueChange = {}, readOnly = true, label = { Text("Paid by") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                        ExposedDropdownMenu(expanded = payerExpanded, onDismissRequest = { payerExpanded = false }) {
                            for (m in members) {
                                DropdownMenuItem(text = { Text(m.name) }, onClick = { payer = m.id; payerExpanded = false })
                            }
                        }
                    }
                    Text("Who shares this expense? (Mess is split equally)", fontWeight = FontWeight.SemiBold)
                    for (m in members) {
                        Row(Modifier.fillMaxWidth().toggleable(selected.contains(m.id)) { checked -> selected = if (checked) selected + m.id else selected - m.id }, verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = selected.contains(m.id), onCheckedChange = null)
                            Text(m.name)
                        }
                    }
                } else {
                    Text("Fixed amount per person • no payer", fontWeight = FontWeight.SemiBold)
                }
                val amount = amountText.toDoubleOrNull()
                if (selected.isNotEmpty() && amount != null && amount > 0) {
                    Text(if (category == "Mess") "Each share: ${money(amount / selected.size)}" else "Fixed amount per person: ${money(amount)}", fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            Button(enabled = amountText.toDoubleOrNull()?.let { it > 0 } == true && selected.isNotEmpty(), onClick = { onSave(title.ifBlank { category }, amountText.toDouble(), if (category == "Mess") payer else 0, selected, category) }) { Text("Save Expense") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
