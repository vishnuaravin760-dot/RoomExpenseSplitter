V7 SYNC REAL FIX: corrected Firebase endpoint fallback/path handling so repeated polling and writes continue to use the selected endpoint.

# Room Expense Splitter

Shared household expense tracker using Firebase Realtime Database REST.

## Important
- No Firebase Android SDK.
- No Firebase Authentication.
- No identitytoolkit.googleapis.com.
- All phones use the same Realtime Database path: `household/default`.
- Firebase rules must allow read/write for this private test app.
- Install the same newly built APK on every phone.

## Main fixes in this version
- Shared expense writes and deletes are optimistic and retried if the network is unavailable.
- Cloud polling runs every 2.5 seconds.
- Pending local changes are protected from being visually overwritten by an older cloud snapshot.
- Mess participant checkboxes are independent.
- A Select all / Clear all control is provided instead of making one checkbox select everyone.
- App launcher icon resources are included.


Household Code: the app uses a 6-digit household code. All phones using the same code share the same Realtime Database path under /households/{code}.


## Mess fixes in v1.4
- Mess screen is month-aware; use the left/right month buttons to view each month separately.
- Mess totals and person-wise paid amounts are calculated only for the selected month.
- Mess payment history includes a Delete action for current expense records.
- Legacy Mess payments are filtered to their own month and deduplicated by id when a migrated expense exists.

## Experimental features in this ZIP
- Biometric/device-credential prompt is shown when the app starts, when the device has biometric or screen-lock authentication configured. If no supported authentication is configured, the app opens without a lock to avoid locking the user out.
- The Add Expense dialog includes receipt image selection and a camera photo option. In this revision, receipt images are only selected/saved temporarily on the current phone; they are NOT attached to the expense record or synchronized to other phones yet. Do not rely on this as cloud receipt storage.
- This is a source-code ZIP, not a tested APK. Build and test it in Android Studio or GitHub Actions before installing it.
