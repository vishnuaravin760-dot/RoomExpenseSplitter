# RoomExpenseSplitter

Android household expense tracker.

## Current behavior
- Tracker is designed as a **single-page, non-scrolling table** so the whole monthly summary is visible at once.
- **Car is hidden by default**. Tap `Car: Hidden` only if you want to temporarily show the Car column.
- **Mess**: choose the payer and selected people; the total is split equally among selected people.
- **Rent / Gas / Water / Lottery / Other**: the entered number is treated as a fixed amount per person; there is no `Paid by` field and the amount is not multiplied or divided.

## GitHub Actions upload
Keep the project folder structure intact:

```text
RoomExpenseSplitter/
  app/
  build.gradle.kts
  settings.gradle.kts
```

The GitHub Actions workflow should build from `RoomExpenseSplitter` as its working directory.
