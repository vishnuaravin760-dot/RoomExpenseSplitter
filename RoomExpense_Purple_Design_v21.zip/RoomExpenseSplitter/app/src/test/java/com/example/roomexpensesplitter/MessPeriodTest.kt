package com.example.roomexpensesplitter

import java.time.LocalDate
import org.junit.Assert.*
import org.junit.Test

class MessPeriodTest {
    @Test fun periodKeepsEntriesAcrossCalendarMonthChange() {
        val from = LocalDate.of(2026, 9, 26)
        val to = LocalDate.of(2026, 10, 26)
        for (date in listOf("26.09.2026", "30.09.2026", "01.10.2026", "26.10.2026"))
            assertTrue(messDateInRange(date, from, to))
        assertFalse(messDateInRange("25.09.2026", from, to))
        assertFalse(messDateInRange("27.10.2026", from, to))
    }
    @Test fun datesCanBeChangedAndInvalidDatesAreRejected() {
        assertTrue(messDateInRange("01.10.2026", LocalDate.of(2026, 9, 28), LocalDate.of(2026, 10, 25)))
        assertNull(parseMessDate("31.02.2026"))
        assertNotNull(parseMessDate("29.02.2028"))
        assertNull(parseMessDate("not a date"))
    }
}
