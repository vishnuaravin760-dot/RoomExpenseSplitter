package com.example.roomexpensesplitter

import org.junit.Assert.*
import org.junit.Test

class SplitLogicTest {
    private val people = setOf(1, 2, 3, 4, 5, 6, 7)
    private val meal = mapOf(2 to 3000L, 3 to 2000L, 7 to 5000L)

    @Test fun customMealUsesIndividualAmountsAndCreditsThePayer() {
        assertTrue(validCustomSplit(10000L, meal))
        assertEquals(-70.0, trackerContribution(100.0, "Mess", "custom", meal.keys, meal, 2, 2, people), 0.000001)
        assertEquals(20.0, trackerContribution(100.0, "Mess", "custom", meal.keys, meal, 2, 3, people), 0.000001)
        assertEquals(50.0, trackerContribution(100.0, "Mess", "custom", meal.keys, meal, 2, 7, people), 0.000001)
        assertEquals(0.0, trackerContribution(100.0, "Mess", "custom", meal.keys, meal, 2, 1, people), 0.000001)
        assertEquals(0.0, people.sumOf { trackerContribution(100.0, "Mess", "custom", meal.keys, meal, 2, it, people) }, 0.000001)
    }

    @Test fun nonEatingPayerStillGetsCreditForTheFullBill() {
        assertEquals(-100.0, trackerContribution(100.0, "Other", "custom", meal.keys, meal, 1, 1, people), 0.000001)
        assertEquals(30.0, trackerContribution(100.0, "Other", "custom", meal.keys, meal, 1, 2, people), 0.000001)
    }

    @Test fun equalSplitRemainsAvailableForSelectedPeople() {
        val selected = setOf(2, 3, 7)
        for (category in listOf("Mess", "Other")) {
            assertEquals(40.0, trackerContribution(120.0, category, "equal", selected, emptyMap(), 1, 2, people), 0.000001)
            assertEquals(0.0, trackerContribution(120.0, category, "equal", selected, emptyMap(), 1, 4, people), 0.000001)
            assertEquals(-120.0, trackerContribution(120.0, category, "equal", selected, emptyMap(), 1, 1, people), 0.000001)
        }
    }

    @Test fun oldOtherRecordsAndFixedCategoriesKeepTheirExistingMeaning() {
        for (category in listOf("Rent", "Gas / Water", "Lottery", "Car", "Other")) {
            assertEquals(343.0, trackerContribution(343.0, category, "legacy", people, emptyMap(), 2, 2, people), 0.000001)
            assertEquals(343.0, trackerContribution(343.0, category, "legacy", emptySet(), emptyMap(), 2, 3, people), 0.000001)
        }
        assertEquals(-80.0, trackerContribution(120.0, "Mess", "legacy", setOf(2, 3, 7), emptyMap(), 2, 2, people), 0.000001)
    }

    @Test fun saveRejectsMissingExcessAndNegativeAllocations() {
        assertFalse(validCustomSplit(10000L, mapOf(2 to 3000L, 3 to 2000L)))
        assertFalse(validCustomSplit(10000L, mapOf(2 to 3000L, 3 to 2000L, 7 to 6000L)))
        assertFalse(validCustomSplit(10000L, mapOf(2 to -100L, 3 to 10100L)))
        assertFalse(validCustomSplit(0L, emptyMap()))
        assertFalse(validCustomSplit(null, meal))
    }

    @Test fun decimalAmountsAreValidatedExactlyInPaise() {
        assertEquals(3010L, moneyPaise("30.10"))
        assertEquals(0L, moneyPaise(""))
        assertNull(moneyPaise("0.001"))
        assertNull(moneyPaise("1..0"))
        assertNull(moneyPaise("-20"))
        assertTrue(validCustomSplit(30L, mapOf(2 to 10L, 3 to 20L)))
    }
}
