package com.example.roomexpensesplitter

import android.content.Intent
import android.net.Uri
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private const val RELEASE_API = "https://api.github.com/repos/vishnuaravin760-dot/RoomExpenseSplitter/releases/latest"
private const val RELEASE_PREFIX = "https://github.com/vishnuaravin760-dot/RoomExpenseSplitter/releases/download/"
private data class AvailableUpdate(val code: Long, val url: String)

@Composable
fun AppUpdateNotice(activity: MainActivity) {
    var update by remember { mutableStateOf<AvailableUpdate?>(null) }
    LaunchedEffect(Unit) {
        update = withContext(Dispatchers.IO) {
            try {
                val connection = URL(RELEASE_API).openConnection() as HttpURLConnection
                connection.connectTimeout = 8000
                connection.readTimeout = 8000
                connection.setRequestProperty("Accept", "application/vnd.github+json")
                connection.setRequestProperty("User-Agent", "RoomExpenseSplitter")
                try {
                    if (connection.responseCode != 200) return@withContext null
                    val release = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
                    if (release.optBoolean("draft") || release.optBoolean("prerelease")) return@withContext null
                    val code = release.optString("tag_name").removePrefix("app-v").toLongOrNull()
                        ?: return@withContext null
                    @Suppress("DEPRECATION")
                    val installed = activity.packageManager.getPackageInfo(activity.packageName, 0).versionCode.toLong()
                    if (code <= installed) return@withContext null
                    val assets = release.optJSONArray("assets") ?: return@withContext null
                    var found: AvailableUpdate? = null
                    for (i in 0 until assets.length()) {
                        val asset = assets.getJSONObject(i)
                        val link = asset.optString("browser_download_url")
                        if (asset.optString("name") == "app-debug.apk" && link.startsWith(RELEASE_PREFIX)) {
                            found = AvailableUpdate(code, link)
                            break
                        }
                    }
                    found
                } finally { connection.disconnect() }
            } catch (_: Exception) { null }
        }
    }
    update?.let { available ->
        AlertDialog(
            onDismissRequest = { update = null },
            title = { Text("New update available") },
            text = { Text("Download the latest Room Expenses APK, then open it and tap Update. Your phone will ask you to confirm installation.") },
            confirmButton = {
                TextButton(onClick = {
                    try {
                        activity.beginExternalActivity()
                        activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(available.url)))
                        update = null
                    } catch (_: Exception) { activity.externalActivityFinished() }
                }) { Text("Download update") }
            },
            dismissButton = { TextButton(onClick = { update = null }) { Text("Later") } }
        )
    }
}
