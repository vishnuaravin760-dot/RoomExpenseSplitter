package com.example.roomexpensesplitter

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private data class RoomNote(val id: String, val author: String, val text: String, val time: Long)
private suspend fun notesRequest(room: String, path: String = "", body: String? = null): String =
    withContext(Dispatchers.IO) {
        var failure: Exception? = null
        for (host in listOf("roomexpensesplitter-47254-default-rtdb.firebaseio.com", "roomexpensesplitter-47254-default-rtdb.firebasedatabase.app")) {
            try {
                val connection = URL("https://$host/households/$room/notes$path.json").openConnection() as HttpURLConnection
                connection.connectTimeout = 7000
                connection.readTimeout = 7000
                try {
                    if (body != null) {
                        connection.requestMethod = "PUT"
                        connection.doOutput = true
                        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    }
                    check(connection.responseCode in 200..299)
                    return@withContext connection.inputStream.bufferedReader().use { it.readText() }
                } finally { connection.disconnect() }
            } catch (e: Exception) { failure = e }
        }
        throw failure ?: IllegalStateException("Notes unavailable")
    }

@Composable
fun RoomNotesButton(context: Context, room: String, author: String) {
    val prefs = remember(room) { context.getSharedPreferences("room_notes", Context.MODE_PRIVATE) }
    var notes by remember(room) { mutableStateOf<List<RoomNote>>(emptyList()) }
    var seen by remember(room) { mutableStateOf(prefs.getStringSet("seen_$room", null)?.toSet()) }
    var popup by remember(room) { mutableStateOf<RoomNote?>(null) }
    var open by remember(room) { mutableStateOf(false) }
    var draft by remember(room) { mutableStateOf("") }
    var sending by remember(room) { mutableStateOf(false) }
    var error by remember(room) { mutableStateOf<String?>(null) }
    var outgoing by remember(room) { mutableStateOf<RoomNote?>(null) }
    var sendAttempt by remember(room) { mutableIntStateOf(0) }
    fun markSeen(ids: Set<String>) {
        val updated = (seen ?: emptySet()) + ids
        seen = updated
        prefs.edit().putStringSet("seen_$room", updated).apply()
    }
    LaunchedEffect(room) {
        while (true) {
            try {
                val raw = notesRequest(room)
                val root = if (raw == "null") JSONObject() else JSONObject(raw)
                val loaded = root.keys().asSequence().mapNotNull { id ->
                    val value = root.optJSONObject(id) ?: return@mapNotNull null
                    RoomNote(id, value.optString("author", "Member"), value.optString("text"), value.optLong("time"))
                }.filter { it.text.isNotBlank() }.sortedByDescending { it.time }.toList()
                notes = loaded
                if (seen == null || open) markSeen(loaded.map { it.id }.toSet())
                else if (popup == null) popup = loaded.firstOrNull { it.id !in seen.orEmpty() }
                error = null
            } catch (_: Exception) { error = "Cannot load notes. Check internet; retrying…" }
            delay(3000)
        }
    }
    LaunchedEffect(sendAttempt) {
        val note = outgoing ?: return@LaunchedEffect
        sending = true
        try {
            val body = JSONObject().put("author", note.author).put("text", note.text).put("time", note.time).toString()
            notesRequest(room, "/${note.id}", body)
            markSeen(setOf(note.id))
            notes = (notes.filterNot { it.id == note.id } + note).sortedByDescending { it.time }
            draft = ""
            outgoing = null
            error = null
        } catch (_: Exception) {
            error = "Note not sent. Tap Send to retry."
            // Keep the same ID on retry to avoid duplicate notes.
        } finally { sending = false }
    }
    TextButton(onClick = { open = true; markSeen(notes.map { it.id }.toSet()); popup = null }) {
        Text("📝 Room Notes")
    }
    if (open) AlertDialog(
        onDismissRequest = { if (!sending) open = false },
        title = { Text("Room Notes") },
        text = {
            Column {
                OutlinedTextField(value = draft, onValueChange = { if (!sending) { draft = it.take(2000); outgoing = null } },
                    label = { Text("Write a note for everyone") }, modifier = Modifier.fillMaxWidth(), enabled = !sending)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                Spacer(Modifier.height(12.dp))
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 300.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (notes.isEmpty()) item { Text("No notes yet") }
                    items(notes, key = { it.id }) { note ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text(note.author, style = MaterialTheme.typography.titleSmall)
                                Text(note.text)
                                Text(SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(note.time)), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(enabled = !sending && draft.isNotBlank(), onClick = {
            outgoing = outgoing ?: RoomNote(UUID.randomUUID().toString(), author, draft.trim(), System.currentTimeMillis())
            sending = true
            sendAttempt += 1
        }) { Text(if (sending) "Sending…" else "Send") } },
        dismissButton = { TextButton(enabled = !sending, onClick = { open = false }) { Text("Close") } }
    )
    if (!open) popup?.let { note ->
        AlertDialog(onDismissRequest = { markSeen(setOf(note.id)); popup = null },
            title = { Text("New note • ${note.author}") }, text = { Text(note.text) },
            confirmButton = { TextButton(onClick = { open = true; markSeen(notes.map { it.id }.toSet()); popup = null }) { Text("View notes") } },
            dismissButton = { TextButton(onClick = { markSeen(setOf(note.id)); popup = null }) { Text("OK") } })
    }
}
