package com.example.roomexpensesplitter

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File

// Stored with the expense, so existing shared sync and offline retry also sync bills.
data class BillAttachment(val name: String, val mime: String, val data: String)
private const val MAX_BILL_BYTES = 512 * 1024

private fun imageBill(bytes: ByteArray): BillAttachment {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Cannot read this image. Choose a JPG or PNG." }
    var sample = 1
    while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
    val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size,
        BitmapFactory.Options().apply { inSampleSize = sample })
        ?: error("Cannot open this image")
    try {
        var compressed = ByteArray(0)
        for (quality in listOf(85, 70, 55, 40)) {
            val output = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, output)
            compressed = output.toByteArray()
            if (compressed.size <= MAX_BILL_BYTES) break
        }
        require(compressed.size <= MAX_BILL_BYTES) { "Image is too large. Crop the bill and try again." }
        return BillAttachment("Bill.jpg", "image/jpeg", Base64.encodeToString(compressed, Base64.NO_WRAP))
    } finally { bitmap.recycle() }
}

private fun readBill(context: Context, uri: Uri): BillAttachment {
    val mime = context.contentResolver.getType(uri) ?: ""
    require(mime == "application/pdf" || mime.startsWith("image/")) { "Choose a photo or PDF bill." }
    val limit = if (mime == "application/pdf") MAX_BILL_BYTES else 12 * 1024 * 1024
    val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            require(total <= limit) { if (mime == "application/pdf") "PDF must be 512 KB or smaller." else "Photo must be 12 MB or smaller." }
            output.write(buffer, 0, count)
        }
        output.toByteArray()
    } ?: error("Cannot read the selected bill")
    require(bytes.isNotEmpty()) { "The selected file is empty." }
    if (mime.startsWith("image/")) return imageBill(bytes)
    require(bytes.size >= 5 && String(bytes.copyOfRange(0, 5), Charsets.US_ASCII) == "%PDF-") { "This is not a valid PDF." }
    var name = "Bill.pdf"
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) name = cursor.getString(0) ?: name
    }
    return BillAttachment(name.take(100), mime, Base64.encodeToString(bytes, Base64.NO_WRAP))
}

@Composable
fun BillPicker(bill: BillAttachment?, onChange: (BillAttachment?) -> Unit, onBusy: (Boolean) -> Unit) {
    val context = LocalContext.current
    val activity = context as? MainActivity
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var cameraUri by remember { mutableStateOf<Uri?>(null) }
    fun load(uri: Uri) {
        busy = true; onBusy(true); error = null
        scope.launch {
            try { onChange(withContext(Dispatchers.IO) { readBill(context, uri) }) }
            catch (e: Exception) { error = e.message ?: "Cannot attach bill. Try again." }
            finally { busy = false; onBusy(false) }
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        activity?.externalActivityFinished()
        if (uri != null) load(uri)
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        activity?.externalActivityFinished()
        if (success) cameraUri?.let { load(it) }
    }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("Bill (optional) • shared with all room members")
        Row {
            TextButton(enabled = !busy, onClick = {
                try {
                    activity?.beginExternalActivity()
                    picker.launch(arrayOf("image/*", "application/pdf"))
                } catch (e: Exception) { activity?.externalActivityFinished(); error = "No file picker available." }
            }) { Text("Photo / PDF") }
            TextButton(enabled = !busy, onClick = {
                try {
                    val directory = File(context.cacheDir, "bills").apply { mkdirs() }
                    val file = File.createTempFile("capture_", ".jpg", directory)
                    cameraUri = FileProvider.getUriForFile(context, "${context.packageName}.bills", file)
                    activity?.beginExternalActivity()
                    camera.launch(cameraUri!!)
                } catch (e: Exception) { activity?.externalActivityFinished(); error = "Cannot open camera. Choose a photo instead." }
            }) { Text("Camera") }
        }
        if (busy) Text("Preparing bill…")
        if (bill != null) {
            Text("Attached: ${bill.name}")
            TextButton(enabled = !busy, onClick = { onChange(null) }) { Text("Remove bill") }
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Text("PDF: up to 512 KB. Photos are compressed.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun ViewBillButton(expense: Expense) {
    if (expense.billData.isBlank()) return
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    TextButton(enabled = !busy, onClick = {
        busy = true
        scope.launch {
            try {
                val uri = withContext(Dispatchers.IO) {
                    require(expense.billMime == "application/pdf" || expense.billMime == "image/jpeg") { "Unsupported bill format" }
                    val bytes = Base64.decode(expense.billData, Base64.DEFAULT)
                    require(bytes.size <= MAX_BILL_BYTES) { "Bill is too large" }
                    val directory = File(context.cacheDir, "bills").apply { mkdirs() }
                    val file = File(directory, "bill_${expense.id}.${if (expense.billMime == "application/pdf") "pdf" else "jpg"}")
                    file.writeBytes(bytes)
                    FileProvider.getUriForFile(context, "${context.packageName}.bills", file)
                }
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, expense.billMime)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                (context as? MainActivity)?.beginExternalActivity()
                context.startActivity(intent)
            } catch (e: Exception) {
                (context as? MainActivity)?.externalActivityFinished()
                Toast.makeText(context, "Cannot open bill. Install a photo/PDF viewer and try again.", Toast.LENGTH_LONG).show()
            } finally { busy = false }
        }
    }) { Text(if (busy) "Opening…" else "View bill") }
}
