package com.example.roomexpensesplitter

import java.math.BigDecimal
import java.math.RoundingMode

// Parse money exactly in paise; no floating-point tolerance when validating bills.
internal fun moneyPaise(text: String): Long? {
    if (text.isBlank()) return 0L
    return try {
        val value = BigDecimal(text.trim()).setScale(2, RoundingMode.UNNECESSARY)
            .movePointRight(2).longValueExact()
        value.takeIf { it in 0L..1_000_000_000_000L }
    } catch (_: Exception) { null }
}

internal fun validCustomSplit(amount: Long?, shares: Map<Int, Long>): Boolean =
    amount != null && amount > 0L && shares.isNotEmpty() &&
        shares.keys.all { it > 0 } && shares.values.all { it >= 0L && it <= amount } &&
        shares.values.fold(0L) { total, share -> Math.addExact(total, share) } == amount

internal fun splitCharge(amount: Double, mode: String, participants: Set<Int>,
                         customShares: Map<Int, Long>, memberId: Int): Double =
    if (mode == "custom") (customShares[memberId] ?: 0L) / 100.0
    else if (memberId in participants && participants.isNotEmpty()) amount / participants.size
    else 0.0

internal fun supportsSplitChoice(category: String): Boolean =
    category == "Mess" || category == "Other" || category == "Others"

internal fun trackerContribution(amount: Double, category: String, mode: String,
    participants: Set<Int>, customShares: Map<Int, Long>, payerId: Int,
    memberId: Int, allMemberIds: Set<Int>): Double {
    if (category == "Mess" || (supportsSplitChoice(category) && mode in setOf("equal", "custom"))) {
        val charge = splitCharge(amount, mode, participants, customShares, memberId)
        return charge - if (payerId == memberId) amount else 0.0
    }
    val effectiveParticipants = participants.ifEmpty { allMemberIds }
    return if (memberId in effectiveParticipants) amount else 0.0
}
