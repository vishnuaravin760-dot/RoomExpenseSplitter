package com.example.roomexpensesplitter

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val RoomColors = lightColorScheme(
    primary = Color(0xFF6236DC), onPrimary = Color.White,
    primaryContainer = Color(0xFFEDE5FF), onPrimaryContainer = Color(0xFF30126E),
    secondary = Color(0xFF675880), secondaryContainer = Color(0xFFF0EAFE),
    background = Color(0xFFFAF8FF), onBackground = Color(0xFF211735),
    surface = Color.White, onSurface = Color(0xFF211735),
    surfaceVariant = Color(0xFFF2EDFA), onSurfaceVariant = Color(0xFF655B75),
    outline = Color(0xFFD7CDE7), error = Color(0xFFB3261E)
)

@Composable
fun PurpleRoomTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = RoomColors,
        shapes = Shapes(small = RoundedCornerShape(12.dp), medium = RoundedCornerShape(18.dp), large = RoundedCornerShape(24.dp)),
        content = content)
}
