package com.example.roomexpensesplitter

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.ui.semantics.Role
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.time.LocalDate
import java.util.Locale

data class Member(val id: Int = 0, val name: String = "")
data class DeletionNotice(
    val eventId: String,
    val expenseId: Long,
    val title: String,
    val amount: Double,
    val category: String,
    val payerId: Int,
    val deletedById: Int = 0,
    val deletedByName: String = ""
)
data class MessPayment(
    val id: Long = 0L,
    val date: String = "",
    val amount: Double = 0.0,
    val payerId: Int = 0
)
data class Expense(
    val id: Long = 0L,
    val title: String = "Expense",
    val amount: Double = 0.0,
    val payerId: Int = 0,
    val participants: Set<Int> = emptySet(),
    val month: String = "",
    val category: String = "Other",
    val date: String = "",
    val billName: String = "",
    val billMime: String = "",
    val billData: String = "",
    val splitMode: String = "legacy",
    val customShares: Map<Int, Long> = emptyMap()
)

private val categories = listOf("Mess", "Rent", "Gas / Water", "Lottery", "Car", "Others")

private fun usesPaidBy(category: String): Boolean =
    category == "Mess" || category == "Car" || category == "Other" || category == "Others"
private val defaultMembers = listOf(
    Member(1, "maneesh"), Member(2, "vishnu"), Member(3, "aneesh"),
    Member(4, "githin"), Member(5, "binish"), Member(6, "shahul"), Member(7, "anoop")
)

/**
 * Shared cloud store. Every installed copy of the app reads/writes the same
 * household/default path, so an expense added on one phone appears on all
 * other phones in real time.
 */
class FirebaseExpenseStore(private val context: Context, private val roomCode: String) {
    // Direct Realtime Database REST sync. No Firebase Authentication call is
    // needed, so a DNS problem resolving identitytoolkit.googleapis.com cannot
    // block adding expenses. The database rules must permit read/write access
    // for this shared household path.
    // Try both Firebase Realtime Database hostnames. Some mobile networks/DNS
    // resolvers fail to resolve the legacy *.firebaseio.com hostname even though
    // the database itself is reachable. The active URL is remembered after a
    // successful request, so all reads/writes use the working endpoint.
    private val databaseUrls = listOf(
        "https://roomexpensesplitter-47254-default-rtdb.firebaseio.com",
        "https://roomexpensesplitter-47254-default-rtdb.firebasedatabase.app"
    )
    @Volatile private var activeDatabaseUrl: String? = null
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    @Volatile private var running = false
    private val pollGeneration = java.util.concurrent.atomic.AtomicInteger(0)
    private val pollMutex = Any()
    private var onDataCallback: ((List<Member>, List<Expense>, List<DeletionNotice>, List<MessPayment>) -> Unit)? = null
    private var onReadyCallback: (() -> Unit)? = null
    private var onErrorCallback: ((String) -> Unit)? = null
    private val pendingExpenses = java.util.Collections.synchronizedList(mutableListOf<Expense>())
    private val pendingDeletes = java.util.Collections.synchronizedList(mutableListOf<Long>())
    private val pendingMembers = java.util.Collections.synchronizedList(mutableListOf<List<Member>>())
    private val pendingDeletionEvents = java.util.Collections.synchronizedList(mutableListOf<DeletionNotice>())
    // IDs currently being written/deleted. While a write is in flight, an older
    // cloud poll must not make the local UI briefly show stale data again.
    private val pendingExpenseIds = java.util.Collections.synchronizedSet(mutableSetOf<Long>())
    private val pendingMessPayments = java.util.Collections.synchronizedList(mutableListOf<MessPayment>())
    private val pendingDeleteIds = java.util.Collections.synchronizedSet(mutableSetOf<Long>())
    private val pendingMessDeleteIds = java.util.Collections.synchronizedSet(mutableSetOf<Long>())

    fun start(
        onData: (List<Member>, List<Expense>, List<DeletionNotice>, List<MessPayment>) -> Unit,
        onReady: () -> Unit,
        onError: (String) -> Unit
    ) {
        if (running) return
        running = true
        onDataCallback = onData
        onReadyCallback = onReady
        onErrorCallback = onError
        val generation = pollGeneration.incrementAndGet()
        Thread { synchronized(pollMutex) { pollLoop(generation) } }.start()
    }

    private fun flushPendingWrites() {
        val messToSave = synchronized(pendingMessPayments) {
            val copy = pendingMessPayments.toList()
            pendingMessPayments.clear()
            copy
        }
        messToSave.forEach { p ->
            try { putMessPayment(p) } catch (_: Throwable) { pendingMessPayments.add(p) }
        }

        val messDeletesToApply = synchronized(pendingMessDeleteIds) {
            pendingMessDeleteIds.toList()
        }
        messDeletesToApply.forEach { id ->
            try {
                httpDelete("${baseUrl()}/households/$roomCode/messPayments/$id.json")
                pendingMessDeleteIds.remove(id)
            } catch (_: Throwable) { /* retry on next poll */ }
        }

        val expensesToSave = synchronized(pendingExpenses) {
            val copy = pendingExpenses.toList()
            pendingExpenses.clear()
            copy
        }
        expensesToSave.forEach { e ->
            try { putExpense(e); pendingExpenseIds.remove(e.id) } catch (_: Throwable) { pendingExpenses.add(e) }
        }

        val deletionEventsToSave = synchronized(pendingDeletionEvents) {
            val copy = pendingDeletionEvents.toList()
            pendingDeletionEvents.clear()
            copy
        }
        deletionEventsToSave.forEach { notice ->
            try { putDeletionEvent(notice) } catch (_: Throwable) { pendingDeletionEvents.add(notice) }
        }

        val deletesToApply = synchronized(pendingDeletes) {
            val copy = pendingDeletes.toList()
            pendingDeletes.clear()
            copy
        }
        deletesToApply.forEach { id ->
            try { httpDelete("${baseUrl()}/households/$roomCode/expenses/$id.json"); pendingDeleteIds.remove(id) }
            catch (_: Throwable) { pendingDeletes.add(id) }
        }

        val latestMembers = synchronized(pendingMembers) { pendingMembers.removeLastOrNull() }
        if (latestMembers != null) {
            try { putMembers(latestMembers) } catch (_: Throwable) { pendingMembers.add(latestMembers) }
        }
    }

    private fun pollLoop(generation: Int) {
        var announcedReady = false
        while (running && pollGeneration.get() == generation) {
            try {
                flushPendingWrites()
                val json = httpGet("${baseUrl()}/households/$roomCode.json")
                val (members, cloudExpenses) = parseRoot(json)
                val messPayments = parseMessPayments(json).filterNot { pendingMessDeleteIds.contains(it.id) }
                val deletionNotices = parseDeletionNotices(json)
                val expenses = cloudExpenses.filterNot { pendingDeleteIds.contains(it.id) }
                    .let { cloud ->
                        val byId = cloud.associateBy { it.id }.toMutableMap()
                        synchronized(pendingExpenses) { pendingExpenses.forEach { byId[it.id] = it } }
                        synchronized(pendingExpenseIds) { pendingExpenseIds.forEach { id ->
                            // Keep any locally pending record until its PUT succeeds.
                            synchronized(pendingExpenses) { pendingExpenses.firstOrNull { it.id == id }?.let { byId[id] = it } }
                        } }
                        byId.values.sortedBy { it.id }
                    }
                handler.post {
                    if (!running || pollGeneration.get() != generation) return@post
                    onDataCallback?.invoke(members, expenses, deletionNotices, messPayments)
                    if (!announcedReady) {
                        announcedReady = true
                        onReadyCallback?.invoke()
                    }
                }
            } catch (t: Throwable) {
                handler.post {
                    if (!running || pollGeneration.get() != generation) return@post
                    // Do not block the Add dialog with a Firebase error popup.
                    // Keep the app usable offline and retry automatically.
                    onErrorCallback?.invoke("Sync temporarily unavailable. Local changes will retry automatically.")
                }
            }
            try { Thread.sleep(2500) } catch (_: InterruptedException) { break }
        }
    }

    private fun putExpense(e: Expense) {
        // Store Mess participants as an explicit JSON array.
        // This preserves an exact selection such as 3/7, and also preserves
        // an intentional empty selection without it being confused with
        // legacy records that had no participant field.
        val participants = org.json.JSONArray().apply {
            e.participants.sorted().forEach { put(it) }
        }
        val data = org.json.JSONObject().apply {
            put("id", e.id)
            put("title", e.title)
            put("amount", e.amount)
            put("payerId", e.payerId)
            put("participants", participants)
            put("month", e.month)
            put("category", e.category)
            put("date", e.date)
            put("billName", e.billName)
            put("billMime", e.billMime)
            put("billData", e.billData)
            put("splitMode", e.splitMode)
            put("customShares", org.json.JSONObject().apply {
                e.customShares.forEach { (memberId, paise) -> put("m$memberId", paise) }
            })
        }
        httpPut("${baseUrl()}/households/$roomCode/expenses/${e.id}.json", data.toString())
    }

    private fun putMessPayment(p: MessPayment) {
        val data = org.json.JSONObject().apply {
            put("id", p.id)
            put("date", p.date)
            put("amount", p.amount)
            put("payerId", p.payerId)
        }
        httpPut("${baseUrl()}/households/$roomCode/messPayments/${p.id}.json", data.toString())
    }

    private fun putMembers(members: List<Member>) {
        val data = org.json.JSONObject().apply {
            members.forEach { m ->
                put(m.id.toString(), org.json.JSONObject().apply {
                    put("id", m.id)
                    put("name", m.name)
                })
            }
        }
        httpPut("${baseUrl()}/households/$roomCode/members.json", data.toString())
    }

    private fun baseUrl(): String = activeDatabaseUrl ?: databaseUrls.first()

    private fun <T> withDatabaseFallback(request: (String) -> T): T {
        val preferred = activeDatabaseUrl
        val candidates = if (preferred != null) {
            listOf(preferred) + databaseUrls.filter { it != preferred }
        } else databaseUrls
        var last: Throwable? = null
        for (base in candidates) {
            try {
                val result = request(base)
                activeDatabaseUrl = base
                return result
            } catch (t: Throwable) {
                last = t
            }
        }
        throw last ?: IllegalStateException("No Firebase endpoint available")
    }

    private fun databasePath(url: String): String {
        for (base in databaseUrls) {
            if (url.startsWith(base)) return url.removePrefix(base)
        }
        return url.substringAfter(".com", url).substringAfter(".app", url)
    }

    private fun httpGet(url: String): String {
        val path = databasePath(url)
        return withDatabaseFallback { base ->
            val conn = (java.net.URL(base + path).openConnection() as java.net.HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 10000
                readTimeout = 10000
            }
            readResponse(conn)
        }
    }

    private fun httpPut(url: String, body: String) {
        val path = databasePath(url)
        withDatabaseFallback { base ->
            val conn = (java.net.URL(base + path).openConnection() as java.net.HttpURLConnection).apply {
                requestMethod = "PUT"
                doOutput = true
                connectTimeout = 10000
                readTimeout = 10000
                setRequestProperty("Content-Type", "application/json")
            }
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            readResponse(conn)
        }
    }

    private fun httpDelete(url: String) {
        val path = databasePath(url)
        withDatabaseFallback { base ->
            val conn = (java.net.URL(base + path).openConnection() as java.net.HttpURLConnection).apply {
                requestMethod = "DELETE"
                connectTimeout = 10000
                readTimeout = 10000
            }
            readResponse(conn)
        }
    }

    private fun readResponse(conn: java.net.HttpURLConnection): String {
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        conn.disconnect()
        if (code !in 200..299) throw IllegalStateException("Firebase HTTP $code")
        return text
    }

    private fun parseRoot(json: String): Pair<List<Member>, List<Expense>> {
        if (json == "null" || json.isBlank()) return defaultMembers to emptyList()
        val root = org.json.JSONObject(json)
        val members = mutableListOf<Member>()
        root.optJSONObject("members")?.let { obj ->
            obj.keys().forEach { key ->
                val item = obj.optJSONObject(key)
                if (item != null) {
                    val id = item.optInt("id", key.toIntOrNull() ?: 0)
                    val name = item.optString("name", "")
                    if (id != 0 && name.isNotBlank()) members += Member(id, name)
                }
            }
        }
        val finalMembers = members.sortedBy { it.id }.ifEmpty { defaultMembers }
        val expenses = mutableListOf<Expense>()
        root.optJSONObject("expenses")?.let { obj ->
            obj.keys().forEach { key ->
                val item = obj.optJSONObject(key) ?: return@forEach
                val id = item.optLong("id", key.toLongOrNull() ?: 0L)
                if (id == 0L) return@forEach
                val participants = mutableSetOf<Int>()
                // V15 format: explicit JSON array. Also read the older object
                // format so existing shared expenses continue to work.
                item.optJSONArray("participants")?.let { pa ->
                    for (i in 0 until pa.length()) {
                        val pid = pa.optInt(i, 0)
                        if (pid != 0) participants += pid
                    }
                } ?: item.optJSONObject("participants")?.let { po ->
                    po.keys().forEach { pk ->
                        val v = po.opt(pk)
                        val pid = when (v) {
                            is Number -> v.toInt()
                            else -> pk.toIntOrNull()
                        }
                        if (pid != null && pid != 0) participants += pid
                    }
                }
                val amount = item.optDouble("amount", 0.0)
                val month = item.optString("month", LocalDate.now().toString().substring(0, 7))
                val customShares = mutableMapOf<Int, Long>()
                item.optJSONObject("customShares")?.let { shares ->
                    shares.keys().forEach { key ->
                        val memberId = key.removePrefix("m").toIntOrNull()
                        if (memberId != null && memberId > 0) {
                            customShares[memberId] = shares.optLong(key, 0L).coerceAtLeast(0L)
                        }
                    }
                }
                expenses += Expense(id, item.optString("title", "Expense"), amount,
                    item.optInt("payerId", 0), participants, month,
                    item.optString("category", "Other"),
                    item.optString("date", ""),
                    item.optString("billName", ""), item.optString("billMime", ""), item.optString("billData", ""),
                    item.optString("splitMode", "legacy"), customShares)
            }
        }
        return finalMembers to expenses.sortedBy { it.id }
    }

    private fun parseMessPayments(json: String): List<MessPayment> {
        if (json == "null" || json.isBlank()) return emptyList()
        return try {
            val root = org.json.JSONObject(json)
            val obj = root.optJSONObject("messPayments") ?: return emptyList()
            val result = mutableListOf<MessPayment>()
            obj.keys().forEach { key ->
                val item = obj.optJSONObject(key) ?: return@forEach
                val id = item.optLong("id", key.toLongOrNull() ?: 0L)
                val amount = item.optDouble("amount", 0.0)
                val payerId = item.optInt("payerId", 0)
                val date = item.optString("date", "")
                if (id != 0L && amount > 0.0 && payerId != 0) result += MessPayment(id, date, amount, payerId)
            }
            result.sortedBy { it.id }
        } catch (_: Throwable) { emptyList() }
    }

    private fun putDeletionEvent(notice: DeletionNotice) {
        val data = org.json.JSONObject().apply {
            put("eventId", notice.eventId)
            put("expenseId", notice.expenseId)
            put("title", notice.title)
            put("amount", notice.amount)
            put("category", notice.category)
            put("payerId", notice.payerId)
            put("deletedById", notice.deletedById)
            put("deletedByName", notice.deletedByName)
            put("deletedAt", System.currentTimeMillis())
        }
        httpPut("${baseUrl()}/households/$roomCode/deletionEvents/${notice.eventId}.json", data.toString())
    }

    private fun parseDeletionNotices(json: String): List<DeletionNotice> {
        if (json == "null" || json.isBlank()) return emptyList()
        return try {
            val root = org.json.JSONObject(json)
            val obj = root.optJSONObject("deletionEvents") ?: return emptyList()
            val result = mutableListOf<DeletionNotice>()
            obj.keys().forEach { key ->
                val item = obj.optJSONObject(key) ?: return@forEach
                val eventId = item.optString("eventId", key)
                val expenseId = item.optLong("expenseId", 0L)
                if (eventId.isNotBlank() && expenseId != 0L) {
                    result += DeletionNotice(
                        eventId, expenseId,
                        item.optString("title", "Expense"),
                        item.optDouble("amount", 0.0),
                        item.optString("category", "Other"),
                        item.optInt("payerId", 0),
                        item.optInt("deletedById", 0),
                        item.optString("deletedByName", "")
                    )
                }
            }
            result.sortedBy { it.eventId }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    fun deleteExpense(e: Expense, deletedById: Int, deletedByName: String) {
        pendingDeleteIds.add(e.id)
        val notice = DeletionNotice(
            eventId = "${System.currentTimeMillis()}_${e.id}",
            expenseId = e.id,
            title = e.title,
            amount = e.amount,
            category = e.category,
            payerId = e.payerId,
            deletedById = deletedById,
            deletedByName = deletedByName
        )
        pendingDeletes.add(e.id)
        Thread {
            try {
                httpDelete("${baseUrl()}/households/$roomCode/expenses/${e.id}.json")
                pendingDeletes.remove(e.id)
                pendingDeleteIds.remove(e.id)
                try {
                    putDeletionEvent(notice)
                } catch (_: Throwable) {
                    // The expense is already deleted; retry only the notification event.
                    pendingDeletionEvents.add(notice)
                }
            } catch (_: Throwable) {
                // pollLoop will retry the delete. No deletion notification is emitted
                // until the delete actually succeeds.
            }
        }.start()
    }

    fun saveExpense(e: Expense) {
        pendingExpenseIds.add(e.id)
        pendingExpenses.add(e)
        Thread {
            try { putExpense(e); pendingExpenses.removeIf { it.id == e.id }; pendingExpenseIds.remove(e.id) }
            catch (_: Throwable) { /* pollLoop will retry */ }
        }.start()
    }

    fun saveMessPayment(payment: MessPayment) {
        pendingMessPayments.add(payment)
        Thread {
            try { putMessPayment(payment); pendingMessPayments.removeIf { it.id == payment.id } }
            catch (_: Throwable) { /* pollLoop will retry */ }
        }.start()
    }

    fun deleteMessPayment(payment: MessPayment) {
        // Legacy Mess payments live under /messPayments rather than /expenses.
        // Mark the ID immediately so the 2.5s polling loop cannot put the row
        // back on screen while the delete request is in flight.
        pendingMessDeleteIds.add(payment.id)
        pendingMessPayments.removeIf { it.id == payment.id }
        Thread {
            try {
                httpDelete("${baseUrl()}/households/$roomCode/messPayments/${payment.id}.json")
                pendingMessDeleteIds.remove(payment.id)
            } catch (_: Throwable) {
                // Keep the ID pending; flushPendingWrites() retries automatically.
            }
        }.start()
    }

    fun saveMembers(members: List<Member>) {
        Thread {
            try { putMembers(members) }
            catch (_: Throwable) {
                synchronized(pendingMembers) {
                    pendingMembers.clear()
                    pendingMembers.add(members)
                }
            }
        }.start()
    }

    fun stop() {
        running = false
        pollGeneration.incrementAndGet()
        onDataCallback = null
        onReadyCallback = null
        onErrorCallback = null
    }
}


private fun money(v: Double): String = NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply {
    maximumFractionDigits = 2
    minimumFractionDigits = 2
}.format(v)

private fun categoryNet(
    expenses: List<Expense>,
    memberId: Int,
    category: String,
    allMemberIds: Set<Int> = emptySet()
): Double {
    var value = 0.0
    expenses.filter { (if (it.category == "Other") "Others" else it.category) == category }.forEach { e ->
        value += trackerContribution(e.amount, e.category, e.splitMode,
            e.participants, e.customShares, e.payerId, memberId, allMemberIds)
    }
    return value
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoomExpenseApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("room_expenses", Context.MODE_PRIVATE) }
    var roomCode by remember { mutableStateOf(prefs.getString("room_code", "") ?: "") }
    var codeInput by remember { mutableStateOf("") }
    var store by remember { mutableStateOf<FirebaseExpenseStore?>(null) }
    var members by remember { mutableStateOf(defaultMembers) }
    var expenses by remember { mutableStateOf(emptyList<Expense>()) }
    var messPayments by remember { mutableStateOf(emptyList<MessPayment>()) }
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var firebaseReady by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf<String?>(null) }
    var showRoomLogin by remember { mutableStateOf(roomCode.isBlank()) }
    var showRoomCode by remember { mutableStateOf(false) }
    var showCurrentUser by remember { mutableStateOf(false) }
    var currentUserId by remember { mutableIntStateOf(prefs.getInt("current_user_id_$roomCode", 0)) }
    var month by remember { mutableStateOf(LocalDate.now().toString().substring(0, 7)) }
    val monthExpenses = expenses.filter { it.month == month }
    var deletionNotification by remember { mutableStateOf<String?>(null) }
    var seenDeletionEvents by remember { mutableStateOf(prefs.getStringSet("seen_deletion_events", emptySet()) ?: emptySet()) }
    var hasInitialSync by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    DisposableEffect(Unit) {
        onDispose { store?.stop() }
    }

    fun connectToRoom(code: String) {
        val clean = code.filter { it.isDigit() }.take(6)
        if (clean.length != 6) return
        store?.stop()
        store = (context as? MainActivity)?.roomStore(clean) ?: FirebaseExpenseStore(context.applicationContext, clean)
        members = defaultMembers
        val savedUserId = prefs.getInt("current_user_id_$clean", 0)
        currentUserId = if (defaultMembers.any { it.id == savedUserId }) savedUserId else defaultMembers.firstOrNull()?.id ?: 0
        if (currentUserId != 0) prefs.edit().putInt("current_user_id_$clean", currentUserId).apply()
        expenses = emptyList()
        firebaseReady = false
        errorText = null
        hasInitialSync = false
        roomCode = clean
        prefs.edit().putString("room_code", clean).apply()
        showRoomLogin = false
        store?.start(
            onData = { cloudMembers, cloudExpenses, deletionEvents, cloudMessPayments ->
                members = cloudMembers
                if (cloudMembers.none { it.id == currentUserId }) {
                    currentUserId = cloudMembers.firstOrNull()?.id ?: 0
                    if (currentUserId != 0) prefs.edit().putInt("current_user_id_$roomCode", currentUserId).apply()
                }
                expenses = cloudExpenses
                messPayments = cloudMessPayments
                if (!hasInitialSync) {
                    val allIds = deletionEvents.map { it.eventId }.toSet()
                    seenDeletionEvents = allIds
                    prefs.edit().putStringSet("seen_deletion_events", allIds).apply()
                    hasInitialSync = true
                } else {
                    val fresh = deletionEvents.filter { it.eventId !in seenDeletionEvents }.maxByOrNull { it.eventId }
                    if (fresh != null) {
                        val payerName = members.firstOrNull { it.id == fresh.payerId }?.name
                        val deleterName = fresh.deletedByName.ifBlank { members.firstOrNull { it.id == fresh.deletedById }?.name ?: "Unknown" }
                        deletionNotification = if (usesPaidBy(fresh.category) && payerName != null && fresh.payerId != 0) {
                            "🔔 $deleterName deleted ${fresh.category} ₹${String.format(Locale.US, "%.2f", fresh.amount)} (paid by $payerName)"
                        } else {
                            "🔔 $deleterName deleted ${fresh.category} ₹${String.format(Locale.US, "%.2f", fresh.amount)}"
                        }
                        val updatedSeen = (seenDeletionEvents + deletionEvents.map { it.eventId }).toList().takeLast(100).toSet()
                        seenDeletionEvents = updatedSeen
                        prefs.edit().putStringSet("seen_deletion_events", updatedSeen).apply()
                    }
                }
            },
            onReady = { firebaseReady = true },
            onError = { if (!firebaseReady) errorText = null }
        )
    }

    LaunchedEffect(roomCode) {
        if (roomCode.length == 6 && store == null && !showRoomLogin) connectToRoom(roomCode)
    }

    if (showRoomLogin) {
        PurpleRoomTheme {
            Surface(Modifier.fillMaxSize()) {
                Column(
                    Modifier.fillMaxSize().padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("🏠 HOUSEHOLD EXPENSE TRACKER 💰", fontWeight = FontWeight.Bold, fontSize = 24.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Text("Create or join your household", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(20.dp))
                    OutlinedTextField(
                        value = codeInput,
                        onValueChange = { codeInput = it.filter(Char::isDigit).take(6) },
                        label = { Text("6-digit household code") },
                        placeholder = { Text("Example: 482731") },
                        singleLine = true
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        enabled = codeInput.length == 6,
                        onClick = { connectToRoom(codeInput) }
                    ) { Text("Join Household") }
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(onClick = {
                        val newCode = (100000..999999).random().toString()
                        codeInput = newCode
                        connectToRoom(newCode)
                        showRoomCode = true
                    }) { Text("Create New Household") }
                    Spacer(Modifier.height(16.dp))
                    Text("Use the same code on every phone. Everyone with the same code shares the same expenses.", textAlign = TextAlign.Center, fontSize = 13.sp)
                }
            }
        }
        return
    }

    PurpleRoomTheme {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.background).statusBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Image(painterResource(R.drawable.room_icon), contentDescription = null,
                            modifier = Modifier.size(42.dp))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Room Expenses", fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                            TextButton(onClick = { showCurrentUser = true }, contentPadding = PaddingValues(0.dp)) {
                                Text("You: ${members.firstOrNull { it.id == currentUserId }?.name ?: "Choose name"}")
                            }
                        }
                        TextButton(onClick = { showRoomCode = true }) { Text("Code") }
                        TextButton(onClick = { firebaseReady = false; store?.stop(); store = null; connectToRoom(roomCode) }) {
                            Text(if (firebaseReady) "● Synced" else "↻ Retry", color = if (firebaseReady) Color(0xFF148453) else MaterialTheme.colorScheme.primary,
                                fontSize = 12.sp)
                        }
                    }
                    if (tab != 3) RoomMonthSelector(month, { month = it })
                }
            },
            floatingActionButton = {
                if (tab == 1) ExtendedFloatingActionButton(onClick = { showAdd = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary) {
                    Text("+ Add expense", fontWeight = FontWeight.SemiBold)
                }
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.TableChart, contentDescription = "Tracker") }, label = { Text("Tracker") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.ReceiptLong, contentDescription = "Expenses") }, label = { Text("Expenses") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.People, contentDescription = "People") }, label = { Text("People") })
                    NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Text("🍽️") }, label = { Text("Mess") })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> TrackerScreen(Modifier.padding(padding), members, monthExpenses)
                1 -> ExpensesScreen(Modifier.padding(padding), members, monthExpenses) { deletedExpense ->
                    expenses = expenses.filterNot { it.id == deletedExpense.id }
                    val deletedByName = members.firstOrNull { it.id == currentUserId }?.name ?: "Unknown"
                    store?.deleteExpense(deletedExpense, currentUserId, deletedByName)
                }
                2 -> PeopleScreen(Modifier.padding(padding), members) { updated ->
                    members = updated
                    store?.saveMembers(updated)
                }
                else -> MessScreen(
                    Modifier.padding(padding),
                    members = members,
                    expenses = expenses,
                    legacyPayments = messPayments,
                    onDelete = { deletedExpense ->
                        expenses = expenses.filterNot { it.id == deletedExpense.id }
                        val deletedByName = members.firstOrNull { it.id == currentUserId }?.name ?: "Unknown"
                        store?.deleteExpense(deletedExpense, currentUserId, deletedByName)
                    },
                    onDeleteLegacy = { deletedPayment ->
                        messPayments = messPayments.filterNot { it.id == deletedPayment.id }
                        store?.deleteMessPayment(deletedPayment)
                    }
                )
            }
        }

        LaunchedEffect(deletionNotification) {
        val message = deletionNotification ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(message)
        deletionNotification = null
    }

    if (showAdd) {
        if (tab == 3) {
            AddMessDialog(
                members = members,
                onDismiss = { showAdd = false },
                onSave = { date, amount, payerId, bill ->
                    // Do not reject a payment just because the same person/date/amount
                    // already exists. Those can be separate legitimate old entries.
                    // The dialog closes immediately after one save, which also prevents
                    // the normal single-tap flow from being saved twice.
                    val parsedMonth = try {
                        java.time.LocalDate.parse(
                            date,
                            java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy")
                        ).format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM"))
                    } catch (_: Throwable) {
                        month
                    }
                    val e = Expense(
                        id = System.currentTimeMillis(),
                        title = "Mess",
                        amount = amount,
                        payerId = payerId,
                        participants = members.map { it.id }.toSet(),
                        month = parsedMonth,
                        category = "Mess",
                        date = date,
                        billName = bill?.name ?: "",
                        billMime = bill?.mime ?: "",
                        billData = bill?.data ?: ""
                    )
                    expenses = (expenses + e).distinctBy { it.id }.sortedBy { it.id }
                    store?.saveExpense(e)
                    showAdd = false
                }
            )
        } else {
            AddExpenseDialog(
                members = members,
                onDismiss = { showAdd = false },
                onSave = { title, amount, payer, participants, category, bill, splitMode, customShares ->
                    val finalParticipants = if (supportsSplitChoice(category)) participants else members.map { it.id }.toSet()
                    val e = Expense(
                        id = System.currentTimeMillis(),
                        title = title,
                        amount = amount,
                        payerId = payer,
                        participants = finalParticipants,
                        month = month,
                        category = if (category == "Others") "Other" else category,
                        date = java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy")),
                        billName = bill?.name ?: "",
                        billMime = bill?.mime ?: "",
                        billData = bill?.data ?: "",
                        splitMode = splitMode,
                        customShares = customShares
                    )
                    expenses = (expenses + e).distinctBy { it.id }.sortedBy { it.id }
                    store?.saveExpense(e)
                    showAdd = false
                }
            )
        }
    }

        if (showCurrentUser) {
            AlertDialog(
                onDismissRequest = { showCurrentUser = false },
                title = { Text("👤 Who are you?") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Select your name on this phone. Deletes from this phone will show this name to everyone.", fontSize = 13.sp)
                        members.forEach { member ->
                            Row(
                                Modifier.fillMaxWidth().clickable {
                                    currentUserId = member.id
                                    prefs.edit().putInt("current_user_id_$roomCode", member.id).apply()
                                    showCurrentUser = false
                                }.padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(selected = currentUserId == member.id, onClick = {
                                    currentUserId = member.id
                                    prefs.edit().putInt("current_user_id_$roomCode", member.id).apply()
                                    showCurrentUser = false
                                })
                                Text(member.name)
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showCurrentUser = false }) { Text("Close") } }
            )
        }

        if (showRoomCode) {
            AlertDialog(
                onDismissRequest = { showRoomCode = false },
                title = { Text("🏠 Household Code") },
                text = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Use this exact 6-digit code on the other phones:", textAlign = TextAlign.Center)
                        Spacer(Modifier.height(10.dp))
                        Text(roomCode, fontSize = 32.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                    }
                },
                confirmButton = { TextButton(onClick = { showRoomCode = false }) { Text("OK") } },
                dismissButton = { TextButton(onClick = {
                    showRoomCode = false
                    store?.stop(); store = null
                    prefs.edit().remove("room_code").apply()
                    roomCode = ""
                    codeInput = ""
                    showRoomLogin = true
                }) { Text("Change Code") } }
            )
        }

        errorText?.let { message ->
            AlertDialog(onDismissRequest = { errorText = null }, title = { Text("Sync") }, text = { Text(message) }, confirmButton = { TextButton(onClick = { errorText = null }) { Text("OK") } })
        }
    }
}

@Composable
private fun RoomMonthSelector(month: String, onChange: (String) -> Unit) {
    var choose by remember { mutableStateOf(false) }
    var input by remember(month) { mutableStateOf(month) }
    val parsed = runCatching { java.time.YearMonth.parse(month) }.getOrElse { java.time.YearMonth.now() }
    Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = { onChange(parsed.minusMonths(1).toString()) }) { Text("‹", fontSize = 22.sp) }
            TextButton(onClick = { choose = true }) {
                Text(parsed.format(java.time.format.DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH)), fontWeight = FontWeight.SemiBold)
            }
            TextButton(onClick = { onChange(parsed.plusMonths(1).toString()) }) { Text("›", fontSize = 22.sp) }
        }
    }
    if (choose) AlertDialog(onDismissRequest = { choose = false }, title = { Text("Choose month") },
        text = { OutlinedTextField(value = input, onValueChange = { input = it }, label = { Text("yyyy-MM (example: 2026-10)") }, singleLine = true) },
        confirmButton = { TextButton(enabled = runCatching { java.time.YearMonth.parse(input) }.isSuccess,
            onClick = { onChange(java.time.YearMonth.parse(input).toString()); choose = false }) { Text("Choose") } },
        dismissButton = { TextButton(onClick = { choose = false }) { Text("Cancel") } })
}

@Composable
private fun TrackerScreen(modifier: Modifier, members: List<Member>, expenses: List<Expense>) {
    val memberIds = members.map { it.id }.toSet()
    val totals = categories.associateWith { category -> members.sumOf { categoryNet(expenses, it.id, category, memberIds) } }
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 2.dp), verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(horizontal = 4.dp, vertical = 12.dp)) {
                    Text("Member balances", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("${expenses.size} entries • selected month", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    BoxWithConstraints(Modifier.fillMaxWidth()) {
                        val unitWidth = maxWidth / (categories.size + 2.7f)
                        val nameWidth = unitWidth * 1.5f
                        val totalWidth = unitWidth * 1.2f
                        Column(Modifier.fillMaxWidth()) {
                            Row(Modifier.fillMaxWidth()) {
                                TableCell("NAME", nameWidth, header = true)
                                categories.forEach { TableCell(if (it == "Gas / Water") "GAS /\nWATER" else it.uppercase(), unitWidth, header = true) }
                                TableCell("TOTAL", totalWidth, header = true)
                            }
                            members.forEachIndexed { index, member ->
                                Row(Modifier.fillMaxWidth().background(if (index % 2 == 0) Color.White else Color(0xFFFAF8FF))) {
                                    TableCell(member.name, nameWidth, bold = true)
                                    categories.forEach { category -> TableCell(money(categoryNet(expenses, member.id, category, memberIds)), unitWidth) }
                                    TableCell(money(categories.sumOf { categoryNet(expenses, member.id, it, memberIds) }), totalWidth, bold = true)
                                }
                                HorizontalDivider(color = Color(0xFFF0EAF8))
                            }
                            Row(Modifier.fillMaxWidth()) {
                                TableCell("TOTAL", nameWidth, header = true)
                                categories.forEach { TableCell(money(totals[it] ?: 0.0), unitWidth, header = true) }
                                TableCell(money(totals.values.sum()), totalWidth, header = true)
                            }
                        }
                    }
                }
            }
        }
        item { Text("Category balances", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        items(categories.chunked(2)) { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { category ->
                    Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.padding(14.dp)) {
                            Text(category, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                            Text(money(totals[category] ?: 0.0), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Row(Modifier.padding(18.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total balance", fontWeight = FontWeight.Bold)
                    Text(money(totals.values.sum()), fontSize = 21.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item { Text("Balances include bill-payer credits. Mess/Other: equal or custom shares. Rent, Gas / Water and Lottery: fixed amount per person.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun TableCell(text: String, width: androidx.compose.ui.unit.Dp, header: Boolean = false, bold: Boolean = false) {
    val density = androidx.compose.ui.platform.LocalDensity.current
    val baseSize = if (header) 7.5f else 8f
    val paint = remember { android.graphics.Paint() }
    paint.textSize = with(density) { baseSize.sp.toPx() }
    paint.typeface = if (header || bold) android.graphics.Typeface.DEFAULT_BOLD else android.graphics.Typeface.DEFAULT
    val longest = text.lines().maxOfOrNull { paint.measureText(it) } ?: 1f
    val available = with(density) { (width - 4.dp).toPx() }.coerceAtLeast(1f)
    val fontSize = (baseSize * (available / longest.coerceAtLeast(1f)).coerceAtMost(1f)).sp
    Box(Modifier.width(width).height(if (header) 36.dp else 32.dp)
        .background(if (header) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
        .padding(horizontal = 2.dp), contentAlignment = Alignment.Center) {
        Text(text, fontSize = fontSize, lineHeight = fontSize * 1.2f, maxLines = if (header) 2 else 1,
            textAlign = TextAlign.Center, fontWeight = if (header || bold) FontWeight.SemiBold else FontWeight.Normal,
            color = if (header) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun ExpensesScreen(modifier: Modifier, members: List<Member>, expenses: List<Expense>, onDelete: (Expense) -> Unit) {
    val names = members.associateBy { it.id }
    var filter by remember { mutableStateOf("All") }
    val shown = expenses.filter { filter == "All" || (if (it.category == "Other") "Others" else it.category) == filter }
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 100.dp)) {
        item {
            Text("Filter by category", fontWeight = FontWeight.SemiBold)
            (listOf("All") + categories).chunked(3).forEach { group ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    group.forEach { category ->
                        FilterChip(selected = filter == category, onClick = { filter = category },
                            label = { Text(if (category == "Others") "Other" else category, fontSize = 12.sp) })
                    }
                }
            }
        }
        if (shown.isEmpty()) item {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Text("No entries here. Tap Add expense to create one.", Modifier.padding(20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        items(shown, key = { it.id }) { e ->
            val billSplit = e.category == "Mess" || (supportsSplitChoice(e.category) && e.splitMode in setOf("equal", "custom"))
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(16.dp)) {
                                Text(if (e.category == "Other") "Other" else e.category, Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                                    color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                            }
                            Text(e.title, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(top = 8.dp))
                            if (e.date.isNotBlank()) Text(e.date, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(money(e.amount), fontWeight = FontWeight.Bold, fontSize = 22.sp)
                            if (!billSplit) Text("per person", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    if (usesPaidBy(e.category)) Text("Paid by ${names[e.payerId]?.name ?: "Unknown"}", fontSize = 13.sp)
                    Surface(color = Color(0xFFF6F2FF), shape = RoundedCornerShape(12.dp)) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(if (billSplit) if (e.splitMode == "custom") "Custom split" else "Equal split" else "Fixed amount per person", fontWeight = FontWeight.SemiBold)
                            val detail = if (billSplit && e.splitMode == "custom") {
                                e.customShares.filterValues { it > 0L }.entries.joinToString("  •  ") { (id, paise) ->
                                    "${names[id]?.name ?: "?"} ${money(paise / 100.0)}"
                                }
                            } else if (billSplit) {
                                if (e.participants.isEmpty()) "No members selected" else e.participants.joinToString("  •  ") { id ->
                                    "${names[id]?.name ?: "?"} ${money(e.amount / e.participants.size)}"
                                }
                            } else {
                                (e.participants.ifEmpty { members.map { it.id }.toSet() }).joinToString("  •  ") { names[it]?.name ?: "?" }
                            }
                            Text(detail, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    HorizontalDivider(color = Color(0xFFF0EAF8))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        ViewBillButton(e)
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = { onDelete(e) }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
        }
    }
}

@Composable
private fun PeopleScreen(modifier: Modifier, members: List<Member>, onSave: (List<Member>) -> Unit) {
    var names by remember(members) { mutableStateOf(members.associate { it.id to it.name }) }
    var nextId by remember(members) { mutableIntStateOf((members.maxOfOrNull { it.id } ?: 0) + 1) }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Room members", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(names.keys.toList()) { id ->
                OutlinedTextField(value = names[id] ?: "", onValueChange = { names = names.toMutableMap().apply { put(id, it) } }, label = { Text("Person $id") }, modifier = Modifier.fillMaxWidth())
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { names = names.toMutableMap().apply { put(nextId, "Person $nextId") }; nextId++ }) { Text("Add person") }
            Button(onClick = { onSave(names.map { Member(it.key, it.value.ifBlank { "Person ${it.key}" }) }) }) { Text("Save") }
        }
    }
}

@Composable
private fun MessScreen(
    modifier: Modifier,
    members: List<Member>,
    expenses: List<Expense>,
    legacyPayments: List<MessPayment>,
    onDelete: (Expense) -> Unit,
    onDeleteLegacy: (MessPayment) -> Unit
) {
    data class MessRow(
        val id: Long,
        val date: String,
        val amount: Double,
        val payerId: Int,
        val expense: Expense? = null,
        val legacyPayment: MessPayment? = null
    )

    val names = members.associateBy { it.id }
    var selectedMonth by remember {
        mutableStateOf(java.time.YearMonth.now().toString())
    }

    val expenseRows = expenses
        .filter { it.category == "Mess" && it.month == selectedMonth }
        .map { e ->
            val displayDate = e.date.ifBlank {
                try {
                    java.time.Instant.ofEpochMilli(e.id)
                        .atZone(java.time.ZoneId.systemDefault())
                        .toLocalDate()
                        .format(java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy"))
                } catch (_: Throwable) { "" }
            }
            MessRow(e.id, displayDate, e.amount, e.payerId, e)
        }

    // Older builds stored some Mess payments in /messPayments. Keep every
    // historical payment visible in the month it belongs to. When an old
    // payment was migrated into /expenses, the same payment can exist in both
    // stores. We must hide only the ONE legacy copy that matches each expense;
    // additional matching payments are real historical entries and must remain.
    val legacyRows = legacyPayments
        .filter { payment ->
            val parsedMonth = try {
                java.time.LocalDate.parse(
                    payment.date,
                    java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy")
                ).format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM"))
            } catch (_: Throwable) { "" }
            parsedMonth == selectedMonth
        }
        .map { p -> MessRow(p.id, p.date, p.amount, p.payerId, null, p) }

    // Pair legacy records with current Expense records one-for-one. This fixes
    // migration duplicates without collapsing legitimate repeated payments.
    // Example: 27 + 27 is two real payments, so both stay visible unless one
    // is the migrated copy of the other.
    fun samePayment(a: MessRow, b: MessRow): Boolean {
        val normalizedA = String.format(Locale.US, "%.2f", a.amount)
        val normalizedB = String.format(Locale.US, "%.2f", b.amount)
        return a.date.trim() == b.date.trim() &&
            a.payerId == b.payerId &&
            normalizedA == normalizedB
    }

    val unmatchedLegacy = legacyRows.toMutableList()
    val mergedRows = mutableListOf<MessRow>()
    expenseRows.forEach { expenseRow ->
        mergedRows += expenseRow
        val duplicateIndex = unmatchedLegacy.indexOfFirst { legacyRow -> samePayment(expenseRow, legacyRow) }
        if (duplicateIndex >= 0) unmatchedLegacy.removeAt(duplicateIndex)
    }
    mergedRows += unmatchedLegacy

    val rows = mergedRows.sortedWith(
        compareByDescending<MessRow> { it.id }.thenByDescending { it.expense != null }
    )
    val total = rows.sumOf { it.amount }
    val paidByPerson = rows.groupBy { it.payerId }.mapValues { (_, list) -> list.sumOf { it.amount } }

    val monthLabel = try {
        java.time.YearMonth.parse(selectedMonth)
            .format(java.time.format.DateTimeFormatter.ofPattern("MMMM yyyy"))
    } catch (_: Throwable) { selectedMonth }

    LazyColumn(modifier.fillMaxSize().padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(top = 8.dp, bottom = 100.dp)) {
        item { RoomMonthSelector(selectedMonth, { selectedMonth = it }) }
        item {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFE7F7EE))) {
                Column(Modifier.padding(18.dp)) {
                    Text("Total contributed • $monthLabel", color = Color(0xFF196443), fontWeight = FontWeight.SemiBold)
                    Text(money(total), fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Color(0xFF087A38))
                }
            }
        }
        item { Text("Member contributions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        items(members.chunked(2)) { pair ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { member ->
                    Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(50)) {
                                Box(Modifier.size(32.dp), contentAlignment = Alignment.Center) {
                                    Text(member.name.take(1).uppercase(), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(member.name, fontSize = 13.sp)
                                Text(money(paidByPerson[member.id] ?: 0.0), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            }
                        }
                    }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        item { Text("Contribution history", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        if (rows.isEmpty()) item { Text("No Mess payments for $monthLabel.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(rows) { row ->
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(names[row.payerId]?.name ?: "Unknown", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(row.date, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                        }
                        Text(money(row.amount), fontWeight = FontWeight.Bold, fontSize = 21.sp)
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        row.expense?.let { ViewBillButton(it) }
                        Spacer(Modifier.weight(1f))
                        if (row.expense != null) TextButton(onClick = { onDelete(row.expense) }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
                        else if (row.legacyPayment != null) TextButton(onClick = { onDeleteLegacy(row.legacyPayment) }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddMessDialog(
    members: List<Member>,
    onDismiss: () -> Unit,
    onSave: (String, Double, Int, BillAttachment?) -> Unit
) {
    var date by remember { mutableStateOf(java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy"))) }
    var amountText by remember { mutableStateOf("") }
    var payer by remember { mutableIntStateOf(members.firstOrNull()?.id ?: 1) }
    var payerExpanded by remember { mutableStateOf(false) }
    var bill by remember { mutableStateOf<BillAttachment?>(null) }
    var billBusy by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("➕ Add Mess") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("Date (dd.MM.yyyy)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = amountText, onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Amount (₹)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                ExposedDropdownMenuBox(expanded = payerExpanded, onExpandedChange = { payerExpanded = !payerExpanded }) {
                    OutlinedTextField(value = members.firstOrNull { it.id == payer }?.name ?: "", onValueChange = {}, readOnly = true, label = { Text("Paid by") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = payerExpanded, onDismissRequest = { payerExpanded = false }) {
                        for (m in members) DropdownMenuItem(text = { Text(m.name) }, onClick = { payer = m.id; payerExpanded = false })
                    }
                }
                BillPicker(bill, { bill = it }, { billBusy = it })
            }
        },
        confirmButton = {
            Button(enabled = !billBusy && amountText.toDoubleOrNull()?.let { it > 0 } == true && payer != 0 && date.isNotBlank(), onClick = { onSave(date, amountText.toDouble(), payer, bill) }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddExpenseDialog(
    members: List<Member>,
    onDismiss: () -> Unit,
    onSave: (String, Double, Int, Set<Int>, String, BillAttachment?, String, Map<Int, Long>) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var payer by remember { mutableIntStateOf(members.firstOrNull()?.id ?: 0) }
    var selected by remember(members) { mutableStateOf(members.map { it.id }.toSet()) }
    var category by remember { mutableStateOf("Mess") }
    var categoryExpanded by remember { mutableStateOf(false) }
    var payerExpanded by remember { mutableStateOf(false) }
    var bill by remember { mutableStateOf<BillAttachment?>(null) }
    var billBusy by remember { mutableStateOf(false) }
    var splitMode by remember(category) { mutableStateOf("equal") }
    var customInputs by remember(category) { mutableStateOf<Map<Int, String>>(emptyMap()) }
    val splitCategory = supportsSplitChoice(category)
    val amountPaise = moneyPaise(amountText)
    val parsedShares = members.associate { it.id to moneyPaise(customInputs[it.id] ?: "") }
    val shares = parsedShares.mapValues { (_, value) -> value ?: 0L }
    val sharesValid = parsedShares.values.all { it != null }
    val allocated = shares.values.sum()
    val customValid = sharesValid && validCustomSplit(amountPaise, shares)
    val payerValid = !usesPaidBy(category) || members.any { it.id == payer }
    val saveValid = !billBusy && amountPaise != null && amountPaise > 0L && payerValid &&
        (!splitCategory || if (splitMode == "custom") customValid else selected.isNotEmpty())

    LaunchedEffect(category, members) {
        if (!supportsSplitChoice(category)) selected = members.map { it.id }.toSet()
        else selected = selected.intersect(members.map { it.id }.toSet())
        if (members.none { it.id == payer }) payer = members.firstOrNull()?.id ?: 0
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("➕ Add Expense") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ExposedDropdownMenuBox(expanded = categoryExpanded,
                        onExpandedChange = { categoryExpanded = !categoryExpanded }, modifier = Modifier.weight(1f)) {
                        OutlinedTextField(value = category, onValueChange = {}, readOnly = true,
                            label = { Text("Category") }, modifier = Modifier.menuAnchor().fillMaxWidth(), singleLine = true)
                        ExposedDropdownMenu(expanded = categoryExpanded, onDismissRequest = { categoryExpanded = false }) {
                            for (c in categories) DropdownMenuItem(text = { Text(c) },
                                onClick = { category = c; categoryExpanded = false })
                        }
                    }
                    if (usesPaidBy(category)) {
                        ExposedDropdownMenuBox(expanded = payerExpanded,
                            onExpandedChange = { payerExpanded = !payerExpanded }, modifier = Modifier.weight(1f)) {
                            OutlinedTextField(value = members.firstOrNull { it.id == payer }?.name ?: "",
                                onValueChange = {}, readOnly = true, label = { Text("Paid by") },
                                modifier = Modifier.menuAnchor().fillMaxWidth(), singleLine = true)
                            ExposedDropdownMenu(expanded = payerExpanded, onDismissRequest = { payerExpanded = false }) {
                                for (m in members) DropdownMenuItem(text = { Text(m.name) },
                                    onClick = { payer = m.id; payerExpanded = false })
                            }
                        }
                    }
                }
                OutlinedTextField(value = title, onValueChange = { title = it },
                    label = { Text("Description (optional)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = amountText,
                    onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' || c == '-' } },
                    label = { Text(if (splitCategory) "Total bill amount (₹)" else "Amount per person (₹)") },
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(), singleLine = true)
                if (amountPaise == null) Text("Enter a valid amount with at most 2 decimal places.", color = MaterialTheme.colorScheme.error)
                if (splitCategory) {
                    Text("Split method", fontWeight = FontWeight.SemiBold)
                    Row {
                        Row(Modifier.weight(1f).clickable { splitMode = "equal" }, verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = splitMode == "equal", onClick = { splitMode = "equal" })
                            Text("Equal split")
                        }
                        Row(Modifier.weight(1f).clickable { splitMode = "custom" }, verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = splitMode == "custom", onClick = { splitMode = "custom" })
                            Text("Custom split")
                        }
                    }
                    if (splitMode == "custom") {
                        Text("Enter each person's share. Leave blank for ₹0.")
                        for (m in members) {
                            OutlinedTextField(value = customInputs[m.id] ?: "",
                                onValueChange = { value -> customInputs = customInputs + (m.id to value.filter { it.isDigit() || it == '.' || it == '-' }) },
                                label = { Text("${m.name} • ₹") },
                                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal),
                                isError = parsedShares[m.id] == null,
                                modifier = Modifier.fillMaxWidth(), singleLine = true)
                        }
                        Text("Allocated: ${money(allocated / 100.0)} / ${money((amountPaise ?: 0L) / 100.0)}", fontWeight = FontWeight.Bold)
                        if (!sharesValid) Text("Use non-negative amounts with at most 2 decimal places.", color = MaterialTheme.colorScheme.error)
                        else if (amountPaise != null && amountPaise > 0 && allocated != amountPaise) {
                            Text(if (allocated < amountPaise) "Remaining: ${money((amountPaise - allocated) / 100.0)}"
                                else "Over by: ${money((allocated - amountPaise) / 100.0)}", color = MaterialTheme.colorScheme.error)
                        }
                        if (customValid) Text("Total matches the bill ✓", color = Color(0xFF087A38))
                    } else {
                        Text("Who shares this expense?", fontWeight = FontWeight.SemiBold)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { selected = members.map { it.id }.toSet() }) { Text("Select all") }
                            TextButton(onClick = { selected = emptySet() }) { Text("Clear all") }
                            Text("${selected.size}/${members.size}", modifier = Modifier.padding(top = 12.dp))
                        }
                        for (m in members) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = m.id in selected, onCheckedChange = { checked ->
                                    selected = if (checked) selected + m.id else selected - m.id
                                })
                                Text(m.name)
                            }
                        }
                        if (amountPaise != null && amountPaise > 0 && selected.isNotEmpty())
                            Text("Each share: ${money(amountPaise / 100.0 / selected.size)}", fontWeight = FontWeight.Bold)
                        if (selected.isEmpty()) Text("Select at least one member.", color = MaterialTheme.colorScheme.error)
                    }
                } else Text("Fixed amount per person • applies to all ${members.size} members", fontWeight = FontWeight.SemiBold)
                BillPicker(bill, { bill = it }, { billBusy = it })
            }
        },
        confirmButton = {
            Button(enabled = saveValid, onClick = {
                val value = moneyPaise(amountText) ?: return@Button
                val custom = splitCategory && splitMode == "custom"
                val savedShares = if (custom) shares else emptyMap()
                val savedParticipants = if (custom) shares.filterValues { it > 0L }.keys else selected
                onSave(title.ifBlank { category }, value / 100.0,
                    if (usesPaidBy(category)) payer else 0, savedParticipants, category, bill,
                    if (splitCategory) splitMode else "legacy", savedShares)
            }) { Text("Save Expense") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
