package com.example.roomexpensesplitter

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.ResolverStyle

internal val messDateFormatter: DateTimeFormatter =
    DateTimeFormatter.ofPattern("dd.MM.uuuu").withResolverStyle(ResolverStyle.STRICT)
internal fun parseMessDate(value: String): LocalDate? =
    runCatching { LocalDate.parse(value.trim(), messDateFormatter) }.getOrNull()
        ?: runCatching { LocalDate.parse(value.trim(), DateTimeFormatter.ofPattern("d.M.uuuu").withResolverStyle(ResolverStyle.STRICT)) }.getOrNull()
internal fun messDateInRange(value: String, start: LocalDate, end: LocalDate): Boolean {
    val date = parseMessDate(value) ?: return false
    return !date.isBefore(start) && !date.isAfter(end)
}
