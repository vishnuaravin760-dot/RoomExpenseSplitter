package com.example.roomexpensesplitter

import android.app.KeyguardManager
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

class MainActivity : FragmentActivity() {
    private var unlocked by mutableStateOf(false)
    private var message by mutableStateOf("Unlock with fingerprint or your phone PIN.")
    private var authenticating = false
    private var externalActivity = false
    private lateinit var prompt: BiometricPrompt
    private val roomStores = mutableMapOf<String, FirebaseExpenseStore>()
    fun roomStore(code: String): FirebaseExpenseStore =
        roomStores.getOrPut(code) { FirebaseExpenseStore(applicationContext, code) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    authenticating = false
                    unlocked = true
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    authenticating = false
                    message = errString.toString()
                }
                override fun onAuthenticationFailed() {
                    message = "Fingerprint not recognised. Try again or use your phone PIN."
                }
            })
        setContent {
            MaterialTheme {
                if (unlocked) RoomExpenseApp(this)
                else Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxSize().padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Room Expense • Locked", style = MaterialTheme.typography.headlineSmall)
                        Spacer(Modifier.height(16.dp))
                        Text(message)
                        Spacer(Modifier.height(16.dp))
                        Button(onClick = { unlock() }) { Text("Unlock") }
                        TextButton(onClick = { startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS)) }) {
                            Text("Set up phone fingerprint / PIN")
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        externalActivity = false
        if (!unlocked && !authenticating) unlock()
    }

    override fun onStop() {
        super.onStop()
        if (!externalActivity && !authenticating && !isChangingConfigurations) unlocked = false
    }

    fun beginExternalActivity() { externalActivity = true }
    fun externalActivityFinished() { externalActivity = false }

    private fun unlock() {
        if (authenticating || unlocked) return
        val secure = (getSystemService(KEYGUARD_SERVICE) as KeyguardManager).isDeviceSecure
        if (!secure) {
            message = "First set a PIN or fingerprint in your phone security settings, then tap Unlock."
            return
        }
        val allowed = BiometricManager.Authenticators.BIOMETRIC_WEAK or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        val builder = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock Room Expense")
            .setSubtitle("Use fingerprint or phone PIN / pattern / password")
            .setAllowedAuthenticators(allowed)
        try {
            authenticating = true
            prompt.authenticate(builder.build())
        } catch (e: Exception) {
            authenticating = false
            message = "Cannot start unlock. Check phone security settings and try again."
        }
    }
}
