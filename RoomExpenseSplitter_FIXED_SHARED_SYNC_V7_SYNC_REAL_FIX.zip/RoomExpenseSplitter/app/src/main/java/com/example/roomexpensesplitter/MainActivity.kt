package com.example.roomexpensesplitter

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.time.LocalDate
import java.util.Locale

data class Member(val id: Int = 0, val name: String = "")
data class Expense(
    val id: Long = 0L,
    val title: String = "Expense",
    val amount: Double = 0.0,
    val payerId: Int = 0,
    val participants: Set<Int> = emptySet(),
    val month: String = "",
    val category: String = "Other"
)

private val categories = listOf("Rent", "Gas / Water", "Lottery", "Mess", "Car", "Other")
private val defaultMembers = listOf(
    Member(1, "maneesh"), Member(2, "vishnu"), Member(3, "aneesh"),
    Member(4, "githin"), Member(5, "binish"), Member(6, "shahul"), Member(7, "anoop")
)

/**
 * Shared cloud store. Every installed copy of the app reads/writes the same
 * household/default path, so an expense added on one phone appears on all
 * other phones in real time.
 */
class FirebaseExpenseStore(private val context: Context, private val roomCode: String) {
    // Direct Realtime Database REST sync. No Firebase Authentication call is
    // needed, so a DNS problem resolving identitytoolkit.googleapis.com cannot
    // block adding expenses. The database rules must permit read/write access
    // for this shared household path.
    // Try both Firebase Realtime Database hostnames. Some mobile networks/DNS
    // resolvers fail to resolve the legacy *.firebaseio.com hostname even though
    // the database itself is reachable. The active URL is remembered after a
    // successful request, so all reads/writes use the working endpoint.
    private val databaseUrls = listOf(
        "https://roomexpensesplitter-47254-default-rtdb.firebaseio.com",
        "https://roomexpensesplitter-47254-default-rtdb.firebasedatabase.app"
    )
    @Volatile private var activeDatabaseUrl: String? = null
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private var running = false
    private var onDataCallback: ((List<Member>, List<Expense>) -> Unit)? = null
    private var onReadyCallback: (() -> Unit)? = null
    private var onErrorCallback: ((String) -> Unit)? = null
    private val pendingExpenses = java.util.Collections.synchronizedList(mutableListOf<Expense>())
    private val pendingDeletes = java.util.Collections.synchronizedList(mutableListOf<Long>())
    private val pendingMembers = java.util.Collections.synchronizedList(mutableListOf<List<Member>>())
    // IDs currently being written/deleted. While a write is in flight, an older
    // cloud poll must not make the local UI briefly show stale data again.
    private val pendingExpenseIds = java.util.Collections.synchronizedSet(mutableSetOf<Long>())
    private val pendingDeleteIds = java.util.Collections.synchronizedSet(mutableSetOf<Long>())

    fun start(
        onData: (List<Member>, List<Expense>) -> Unit,
        onReady: () -> Unit,
        onError: (String) -> Unit
    ) {
        if (running) return
        running = true
        onDataCallback = onData
        onReadyCallback = onReady
        onErrorCallback = onError
        Thread { pollLoop() }.start()
    }

    private fun flushPendingWrites() {
        val expensesToSave = synchronized(pendingExpenses) {
            val copy = pendingExpenses.toList()
            pendingExpenses.clear()
            copy
        }
        expensesToSave.forEach { e ->
            try { putExpense(e); pendingExpenseIds.remove(e.id) } catch (_: Throwable) { pendingExpenses.add(e) }
        }

        val deletesToApply = synchronized(pendingDeletes) {
            val copy = pendingDeletes.toList()
            pendingDeletes.clear()
            copy
        }
        deletesToApply.forEach { id ->
            try { httpDelete("${baseUrl()}/households/$roomCode/expenses/$id.json"); pendingDeleteIds.remove(id) }
            catch (_: Throwable) { pendingDeletes.add(id) }
        }

        val latestMembers = synchronized(pendingMembers) { pendingMembers.removeLastOrNull() }
        if (latestMembers != null) {
            try { putMembers(latestMembers) } catch (_: Throwable) { pendingMembers.add(latestMembers) }
        }
    }

    private fun pollLoop() {
        var announcedReady = false
        while (running) {
            try {
                flushPendingWrites()
                val json = httpGet("${baseUrl()}/households/$roomCode.json")
                val (members, cloudExpenses) = parseRoot(json)
                val expenses = cloudExpenses.filterNot { pendingDeleteIds.contains(it.id) }
                    .let { cloud ->
                        val byId = cloud.associateBy { it.id }.toMutableMap()
                        synchronized(pendingExpenses) { pendingExpenses.forEach { byId[it.id] = it } }
                        synchronized(pendingExpenseIds) { pendingExpenseIds.forEach { id ->
                            // Keep any locally pending record until its PUT succeeds.
                            synchronized(pendingExpenses) { pendingExpenses.firstOrNull { it.id == id }?.let { byId[id] = it } }
                        } }
                        byId.values.sortedBy { it.id }
                    }
                handler.post {
                    onDataCallback?.invoke(members, expenses)
                    if (!announcedReady) {
                        announcedReady = true
                        onReadyCallback?.invoke()
                    }
                }
            } catch (t: Throwable) {
                handler.post {
                    // Do not block the Add dialog with a Firebase error popup.
                    // Keep the app usable offline and retry automatically.
                    onErrorCallback?.invoke("Sync temporarily unavailable. Local changes will retry automatically.")
                }
            }
            try { Thread.sleep(2500) } catch (_: InterruptedException) { break }
        }
    }

    private fun putExpense(e: Expense) {
        val participants = org.json.JSONObject().apply {
            e.participants.forEach { put(it.toString(), true) }
        }
        val data = org.json.JSONObject().apply {
            put("id", e.id)
            put("title", e.title)
            put("amount", e.amount)
            put("payerId", e.payerId)
            put("participants", participants)
            put("month", e.month)
            put("category", e.category)
        }
        httpPut("${baseUrl()}/households/$roomCode/expenses/${e.id}.json", data.toString())
    }

    private fun putMembers(members: List<Member>) {
        val data = org.json.JSONObject().apply {
            members.forEach { m ->
                put(m.id.toString(), org.json.JSONObject().apply {
                    put("id", m.id)
                    put("name", m.name)
                })
            }
        }
        httpPut("${baseUrl()}/households/$roomCode/members.json", data.toString())
    }

    private fun baseUrl(): String = activeDatabaseUrl ?: databaseUrls.first()

    private fun <T> withDatabaseFallback(request: (String) -> T): T {
        val preferred = activeDatabaseUrl
        val candidates = if (preferred != null) {
            listOf(preferred) + databaseUrls.filter { it != preferred }
        } else databaseUrls
        var last: Throwable? = null
        for (base in candidates) {
            try {
                val result = request(base)
                activeDatabaseUrl = base
                return result
            } catch (t: Throwable) {
                last = t
            }
        }
        throw last ?: IllegalStateException("No Firebase endpoint available")
    }

    private fun databasePath(url: String): String {
        for (base in databaseUrls) {
            if (url.startsWith(base)) return url.removePrefix(base)
        }
        return url.substringAfter(".com", url).substringAfter(".app", url)
    }

    private fun httpGet(url: String): String {
        val path = databasePath(url)
        return withDatabaseFallback { base ->
            val conn = (java.net.URL(base + path).openConnection() as java.net.HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 10000
                readTimeout = 10000
            }
            readResponse(conn)
        }
    }

    private fun httpPut(url: String, body: String) {
        val path = databasePath(url)
        withDatabaseFallback { base ->
            val conn = (java.net.URL(base + path).openConnection() as java.net.HttpURLConnection).apply {
                requestMethod = "PUT"
                doOutput = true
                connectTimeout = 10000
                readTimeout = 10000
                setRequestProperty("Content-Type", "application/json")
            }
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            readResponse(conn)
        }
    }

    private fun httpDelete(url: String) {
        val path = databasePath(url)
        withDatabaseFallback { base ->
            val conn = (java.net.URL(base + path).openConnection() as java.net.HttpURLConnection).apply {
                requestMethod = "DELETE"
                connectTimeout = 10000
                readTimeout = 10000
            }
            readResponse(conn)
        }
    }

    private fun readResponse(conn: java.net.HttpURLConnection): String {
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        conn.disconnect()
        if (code !in 200..299) throw IllegalStateException("Firebase HTTP $code")
        return text
    }

    private fun parseRoot(json: String): Pair<List<Member>, List<Expense>> {
        if (json == "null" || json.isBlank()) return defaultMembers to emptyList()
        val root = org.json.JSONObject(json)
        val members = mutableListOf<Member>()
        root.optJSONObject("members")?.let { obj ->
            obj.keys().forEach { key ->
                val item = obj.optJSONObject(key)
                if (item != null) {
                    val id = item.optInt("id", key.toIntOrNull() ?: 0)
                    val name = item.optString("name", "")
                    if (id != 0 && name.isNotBlank()) members += Member(id, name)
                }
            }
        }
        val finalMembers = members.sortedBy { it.id }.ifEmpty { defaultMembers }
        val expenses = mutableListOf<Expense>()
        root.optJSONObject("expenses")?.let { obj ->
            obj.keys().forEach { key ->
                val item = obj.optJSONObject(key) ?: return@forEach
                val id = item.optLong("id", key.toLongOrNull() ?: 0L)
                if (id == 0L) return@forEach
                val participants = mutableSetOf<Int>()
                item.optJSONObject("participants")?.let { po ->
                    po.keys().forEach { pk ->
                        val v = po.opt(pk)
                        val pid = when (v) {
                            is Number -> v.toInt()
                            else -> pk.toIntOrNull()
                        }
                        if (pid != null) participants += pid
                    }
                }
                val amount = item.optDouble("amount", 0.0)
                val month = item.optString("month", LocalDate.now().toString().substring(0, 7))
                expenses += Expense(id, item.optString("title", "Expense"), amount,
                    item.optInt("payerId", 0), participants, month,
                    item.optString("category", "Other"))
            }
        }
        return finalMembers to expenses.sortedBy { it.id }
    }

    fun saveExpense(e: Expense) {
        pendingExpenseIds.add(e.id)
        pendingExpenses.add(e)
        Thread {
            try { putExpense(e); pendingExpenses.removeIf { it.id == e.id }; pendingExpenseIds.remove(e.id) }
            catch (_: Throwable) { /* pollLoop will retry */ }
        }.start()
    }

    fun deleteExpense(id: Long) {
        pendingDeleteIds.add(id)
        pendingDeletes.add(id)
        Thread {
            try { httpDelete("${baseUrl()}/households/$roomCode/expenses/$id.json"); pendingDeletes.remove(id); pendingDeleteIds.remove(id) }
            catch (_: Throwable) { /* pollLoop will retry */ }
        }.start()
    }

    fun saveMembers(members: List<Member>) {
        Thread {
            try { putMembers(members) }
            catch (_: Throwable) {
                synchronized(pendingMembers) {
                    pendingMembers.clear()
                    pendingMembers.add(members)
                }
            }
        }.start()
    }

    fun stop() {
        running = false
        onDataCallback = null
        onReadyCallback = null
        onErrorCallback = null
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RoomExpenseApp(this) }
    }
}

private fun money(v: Double): String = NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply {
    maximumFractionDigits = 2
    minimumFractionDigits = 2
}.format(v)

private fun categoryNet(
    expenses: List<Expense>,
    memberId: Int,
    category: String,
    allMemberIds: Set<Int> = emptySet()
): Double {
    var value = 0.0
    expenses.filter { it.category == category }.forEach { e ->
        if (e.category == "Mess") {
            // Equal split. For old records with no participant list, use all
            // current members so the bill does not appear as a single-person charge.
            val participantIds = if (e.participants.isNotEmpty()) e.participants else allMemberIds
            if (participantIds.isNotEmpty() && memberId in participantIds) {
                value += e.amount / participantIds.size.toDouble()
            }
            // Payer paid the full bill, so credit that payment back.
            if (memberId == e.payerId) value -= e.amount
        } else {
            if (memberId in e.participants) value += e.amount
        }
    }
    return value
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoomExpenseApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("room_expenses", Context.MODE_PRIVATE) }
    var roomCode by remember { mutableStateOf(prefs.getString("room_code", "") ?: "") }
    var codeInput by remember { mutableStateOf("") }
    var store by remember { mutableStateOf<FirebaseExpenseStore?>(null) }
    var members by remember { mutableStateOf(defaultMembers) }
    var expenses by remember { mutableStateOf(emptyList<Expense>()) }
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var firebaseReady by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf<String?>(null) }
    var showRoomLogin by remember { mutableStateOf(roomCode.isBlank()) }
    var showRoomCode by remember { mutableStateOf(false) }
    val month = LocalDate.now().toString().substring(0, 7)
    val monthExpenses = expenses.filter { it.month == month }
    var showCar by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        showCar = prefs.getBoolean("show_car_column", false)
        onDispose { store?.stop() }
    }

    fun connectToRoom(code: String) {
        val clean = code.filter { it.isDigit() }.take(6)
        if (clean.length != 6) return
        store?.stop()
        store = FirebaseExpenseStore(context.applicationContext, clean)
        members = defaultMembers
        expenses = emptyList()
        firebaseReady = false
        errorText = null
        roomCode = clean
        prefs.edit().putString("room_code", clean).apply()
        showRoomLogin = false
        store?.start(
            onData = { cloudMembers, cloudExpenses ->
                members = cloudMembers
                expenses = cloudExpenses
            },
            onReady = { firebaseReady = true },
            onError = { if (!firebaseReady) errorText = null }
        )
    }

    LaunchedEffect(roomCode) {
        if (roomCode.length == 6 && store == null && !showRoomLogin) connectToRoom(roomCode)
    }

    if (showRoomLogin) {
        MaterialTheme {
            Surface(Modifier.fillMaxSize()) {
                Column(
                    Modifier.fillMaxSize().padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text("🏠 HOUSEHOLD EXPENSE TRACKER 💰", fontWeight = FontWeight.Bold, fontSize = 24.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Text("Create or join your household", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(20.dp))
                    OutlinedTextField(
                        value = codeInput,
                        onValueChange = { codeInput = it.filter(Char::isDigit).take(6) },
                        label = { Text("6-digit household code") },
                        placeholder = { Text("Example: 482731") },
                        singleLine = true
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        enabled = codeInput.length == 6,
                        onClick = { connectToRoom(codeInput) }
                    ) { Text("Join Household") }
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(onClick = {
                        val newCode = (100000..999999).random().toString()
                        codeInput = newCode
                        connectToRoom(newCode)
                        showRoomCode = true
                    }) { Text("Create New Household") }
                    Spacer(Modifier.height(16.dp))
                    Text("Use the same code on every phone. Everyone with the same code shares the same expenses.", textAlign = TextAlign.Center, fontSize = 13.sp)
                }
            }
        }
        return
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("🏠 HOUSEHOLD EXPENSE TRACKER 💰", fontWeight = FontWeight.Bold)
                            Text(
                                if (firebaseReady) "Household $roomCode • Live Sync ON" else "Household $roomCode • Connecting / retrying…",
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    },
                    actions = {
                        TextButton(onClick = { showRoomCode = true }) { Text("CODE") }
                        TextButton(onClick = { firebaseReady = false; store?.stop(); store = null; connectToRoom(roomCode) }) {
                            Text(if (firebaseReady) "SYNC ON" else "SYNC…")
                        }
                    }
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }) { Text("+") }
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.TableChart, contentDescription = "Tracker") }, label = { Text("Tracker") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.ReceiptLong, contentDescription = "Expenses") }, label = { Text("Expenses") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.People, contentDescription = "People") }, label = { Text("People") })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> TrackerScreen(Modifier.padding(padding), members, monthExpenses, showCar, onToggleCar = {
                    showCar = !showCar
                    prefs.edit().putBoolean("show_car_column", showCar).apply()
                })
                1 -> ExpensesScreen(Modifier.padding(padding), members, monthExpenses) { id ->
                    expenses = expenses.filterNot { it.id == id }
                    store?.deleteExpense(id)
                }
                else -> PeopleScreen(Modifier.padding(padding), members) { updated ->
                    members = updated
                    store?.saveMembers(updated)
                }
            }
        }

        if (showAdd) {
            AddExpenseDialog(
                members = members,
                onDismiss = { showAdd = false },
                onSave = { title, amount, payer, participants, category ->
                    val finalParticipants = if (category == "Mess") {
                        if (participants.isEmpty()) members.map { it.id }.toSet() else participants
                    } else members.map { it.id }.toSet()
                    val e = Expense(System.currentTimeMillis(), title, amount, payer, finalParticipants, month, category)
                    expenses = (expenses + e).distinctBy { it.id }.sortedBy { it.id }
                    store?.saveExpense(e)
                    showAdd = false
                }
            )
        }

        if (showRoomCode) {
            AlertDialog(
                onDismissRequest = { showRoomCode = false },
                title = { Text("🏠 Household Code") },
                text = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Use this exact 6-digit code on the other phones:", textAlign = TextAlign.Center)
                        Spacer(Modifier.height(10.dp))
                        Text(roomCode, fontSize = 32.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                    }
                },
                confirmButton = { TextButton(onClick = { showRoomCode = false }) { Text("OK") } },
                dismissButton = { TextButton(onClick = {
                    showRoomCode = false
                    store?.stop(); store = null
                    prefs.edit().remove("room_code").apply()
                    roomCode = ""
                    codeInput = ""
                    showRoomLogin = true
                }) { Text("Change Code") } }
            )
        }

        errorText?.let { message ->
            AlertDialog(onDismissRequest = { errorText = null }, title = { Text("Sync") }, text = { Text(message) }, confirmButton = { TextButton(onClick = { errorText = null }) { Text("OK") } })
        }
    }
}

@Composable
private fun TrackerScreen(
    modifier: Modifier,
    members: List<Member>,
    expenses: List<Expense>,
    showCar: Boolean,
    onToggleCar: () -> Unit
) {
    val visibleCategories = categories.filter { it != "Car" || showCar }
    val nameWeight = 1.45f
    val cellWeight = 1f
    val totalWeight = nameWeight + (visibleCategories.size + 1) * cellWeight

    BoxWithConstraints(modifier.fillMaxSize()) {
        val nameWidth = maxWidth * (nameWeight / totalWeight)
        val cellWidth = maxWidth * (cellWeight / totalWeight)
        Column(Modifier.fillMaxSize().padding(horizontal = 2.dp, vertical = 1.dp)) {
            Row(Modifier.fillMaxWidth().height(34.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("HOUSEHOLD EXPENSE TRACKER", fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
                    Text("${expenses.size} expense(s) • current month", fontSize = 8.sp, maxLines = 1)
                }
                TextButton(onClick = onToggleCar, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp), modifier = Modifier.height(28.dp)) {
                    Text(if (showCar) "Hide Car" else "Car: Hidden", fontSize = 9.sp, maxLines = 1)
                }
            }
            Row(Modifier.fillMaxWidth().height(30.dp)) {
                CompactHeaderCell("NAME", nameWidth, Color(0xFF123B70))
                for (category in visibleCategories) {
                    CompactHeaderCell(category.replace("Gas / Water", "GAS /\nWATER").uppercase(), cellWidth, Color(0xFF123B70))
                }
                CompactHeaderCell("TOTAL", cellWidth, Color(0xFF0B7A3A))
            }
            for (member in members) {
                Row(Modifier.fillMaxWidth().height(26.dp)) {
                    CompactNameCell(member.name, nameWidth)
                    for (category in visibleCategories) {
                        CompactValueCell(categoryNet(expenses, member.id, category, members.map { it.id }.toSet()), cellWidth)
                    }
                    CompactValueCell(visibleCategories.sumOf { categoryNet(expenses, member.id, it, members.map { it.id }.toSet()) }, cellWidth, total = true)
                }
            }
            Row(Modifier.fillMaxWidth().height(26.dp)) {
                CompactHeaderCell("TOTAL", nameWidth, Color(0xFFDDEBD5), Color.Black)
                for (category in visibleCategories) {
                    CompactValueCell(members.sumOf { categoryNet(expenses, it.id, category, members.map { it.id }.toSet()) }, cellWidth, total = true)
                }
                CompactValueCell(members.sumOf { member -> visibleCategories.sumOf { categoryNet(expenses, member.id, it, members.map { it.id }.toSet()) } }, cellWidth, total = true)
            }
            Text("Mess: equal split • whoever pays the mess bill gets that payment deducted from their total • Rent/Water/Gas/Lottery: fixed amount per person", fontSize = 8.sp, maxLines = 1, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

@Composable
private fun CompactHeaderCell(text: String, width: androidx.compose.ui.unit.Dp, background: Color, textColor: Color = Color.White) {
    Box(Modifier.width(width).height(30.dp).background(background).padding(1.dp), contentAlignment = Alignment.Center) {
        Text(text, color = textColor, fontWeight = FontWeight.Bold, fontSize = 8.sp, lineHeight = 9.sp, textAlign = TextAlign.Center, maxLines = 2)
    }
}

@Composable
private fun CompactNameCell(name: String, width: androidx.compose.ui.unit.Dp) {
    Box(Modifier.width(width).height(26.dp).background(Color(0xFFEAF2F8)).padding(horizontal = 2.dp), contentAlignment = Alignment.CenterStart) {
        Text(name, fontWeight = FontWeight.SemiBold, fontSize = 8.sp, maxLines = 1)
    }
}

@Composable
private fun CompactValueCell(value: Double, width: androidx.compose.ui.unit.Dp, total: Boolean = false) {
    val positive = value > 0.005
    val negative = value < -0.005
    val textColor = when {
        negative -> Color(0xFFB3261E)
        positive && total -> Color(0xFF087A38)
        else -> Color.DarkGray
    }
    Box(Modifier.width(width).height(26.dp).padding(1.dp), contentAlignment = Alignment.Center) {
        Text(money(value), color = textColor, fontWeight = if (total) FontWeight.Bold else FontWeight.Normal, fontSize = 7.sp, maxLines = 1)
    }
}

@Composable
private fun ExpensesScreen(modifier: Modifier, members: List<Member>, expenses: List<Expense>, onDelete: (Long) -> Unit) {
    val names = members.associateBy { it.id }
    LazyColumn(modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (expenses.isEmpty()) item { Text("No expenses this month. Tap + to add one.") }
        items(expenses) { e ->
            Card(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("${e.category} • ${e.title}", fontWeight = FontWeight.Bold)
                        if (e.category == "Mess") {
                            Text("${money(e.amount)} • paid by ${names[e.payerId]?.name ?: "Unknown"}")
                            val participantIds = if (e.participants.isNotEmpty()) e.participants else members.map { it.id }.toSet()
                            val share = if (participantIds.isNotEmpty()) e.amount / participantIds.size else 0.0
                            Text("Split: " + participantIds.joinToString { id ->
                                "${names[id]?.name ?: "?"} ${money(share)}"
                            })
                        } else {
                            Text("${money(e.amount)} • fixed amount per person • no payer")
                            Text("Split: " + e.participants.joinToString { names[it]?.name ?: "?" })
                        }
                    }
                    TextButton(onClick = { onDelete(e.id) }) { Text("Delete") }
                }
            }
        }
    }
}

@Composable
private fun PeopleScreen(modifier: Modifier, members: List<Member>, onSave: (List<Member>) -> Unit) {
    var names by remember(members) { mutableStateOf(members.associate { it.id to it.name }) }
    var nextId by remember(members) { mutableIntStateOf((members.maxOfOrNull { it.id } ?: 0) + 1) }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Room members", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(names.keys.toList()) { id ->
                OutlinedTextField(value = names[id] ?: "", onValueChange = { names = names.toMutableMap().apply { put(id, it) } }, label = { Text("Person $id") }, modifier = Modifier.fillMaxWidth())
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { names = names.toMutableMap().apply { put(nextId, "Person $nextId") }; nextId++ }) { Text("Add person") }
            Button(onClick = { onSave(names.map { Member(it.key, it.value.ifBlank { "Person ${it.key}" }) }) }) { Text("Save") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddExpenseDialog(members: List<Member>, onDismiss: () -> Unit, onSave: (String, Double, Int, Set<Int>, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var payer by remember { mutableIntStateOf(members.firstOrNull()?.id ?: 1) }
    var selected by remember(members) { mutableStateOf(emptySet<Int>()) }
    var category by remember { mutableStateOf("Mess") }
    var categoryExpanded by remember { mutableStateOf(false) }
    var payerExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(category, members) {
        // Fixed expenses (Rent, Electricity, etc.) apply to everyone automatically.
        // Mess keeps manual member selection because it can be split among selected people.
        if (category != "Mess") {
            selected = members.map { it.id }.toSet()
        } else if (selected.isEmpty() && members.isNotEmpty()) {
            selected = emptySet()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("➕ Add Expense") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ExposedDropdownMenuBox(expanded = categoryExpanded, onExpandedChange = { categoryExpanded = !categoryExpanded }) {
                    OutlinedTextField(value = category, onValueChange = {}, readOnly = true, label = { Text("Category") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = categoryExpanded, onDismissRequest = { categoryExpanded = false }) {
                        for (c in categories) {
                            DropdownMenuItem(text = { Text(c) }, onClick = { category = c; categoryExpanded = false })
                        }
                    }
                }
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Description (optional)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = amountText, onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Amount (₹)") }, modifier = Modifier.fillMaxWidth())
                if (category == "Mess") {
                    ExposedDropdownMenuBox(expanded = payerExpanded, onExpandedChange = { payerExpanded = !payerExpanded }) {
                        OutlinedTextField(value = members.firstOrNull { it.id == payer }?.name ?: "", onValueChange = {}, readOnly = true, label = { Text("Paid by") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                        ExposedDropdownMenu(expanded = payerExpanded, onDismissRequest = { payerExpanded = false }) {
                            for (m in members) {
                                DropdownMenuItem(text = { Text(m.name) }, onClick = { payer = m.id; payerExpanded = false })
                            }
                        }
                    }
                    Text("Who shares this expense? (Mess is split equally)", fontWeight = FontWeight.SemiBold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { selected = members.map { it.id }.toSet() }) { Text("Select all") }
                        TextButton(onClick = { selected = emptySet() }) { Text("Clear all") }
                    }
                    for (m in members) {
                        val isSelected = selected.contains(m.id)
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { selected = if (isSelected) selected - m.id else selected + m.id },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isSelected,
                                onCheckedChange = { checked ->
                                    selected = if (checked) selected + m.id else selected - m.id
                                }
                            )
                            Text(m.name)
                        }
                    }
                } else {
                    Text("Fixed amount per person • applies to all ${members.size} members", fontWeight = FontWeight.SemiBold)
                }
                val amount = amountText.toDoubleOrNull()
                if (selected.isNotEmpty() && amount != null && amount > 0) {
                    Text(if (category == "Mess") "Each share: ${money(amount / selected.size)}" else "Fixed amount per person: ${money(amount)}", fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            Button(enabled = amountText.toDoubleOrNull()?.let { it > 0 } == true && selected.isNotEmpty(), onClick = { onSave(title.ifBlank { category }, amountText.toDouble(), if (category == "Mess") payer else 0, selected, category) }) { Text("Save Expense") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
