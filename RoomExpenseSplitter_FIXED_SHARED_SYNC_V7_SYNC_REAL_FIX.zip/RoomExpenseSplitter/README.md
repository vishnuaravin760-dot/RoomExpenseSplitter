V7 SYNC REAL FIX: corrected Firebase endpoint fallback/path handling so repeated polling and writes continue to use the selected endpoint.

# Room Expense Splitter

Shared household expense tracker using Firebase Realtime Database REST.

## Important
- No Firebase Android SDK.
- No Firebase Authentication.
- No identitytoolkit.googleapis.com.
- All phones use the same Realtime Database path: `household/default`.
- Firebase rules must allow read/write for this private test app.
- Install the same newly built APK on every phone.

## Main fixes in this version
- Shared expense writes and deletes are optimistic and retried if the network is unavailable.
- Cloud polling runs every 2.5 seconds.
- Pending local changes are protected from being visually overwritten by an older cloud snapshot.
- Mess participant checkboxes are independent.
- A Select all / Clear all control is provided instead of making one checkbox select everyone.
- App launcher icon resources are included.


Household Code: the app uses a 6-digit household code. All phones using the same code share the same Realtime Database path under /households/{code}.
